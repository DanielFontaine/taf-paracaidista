// Modulo compartido para leer la planilla de postulantes (Google Sheets).

export const SHEET_ID = "1GmGc9RE6KdQV48K1cva0_W2fxzdG6ZpO5c6-h4LMeWE";
export const GID = 94243071;

// Columnas a incluir en el resumen (excluye col 1 vacia, col 2 Grado, y las ultimas 10 cols 22-31)
export const RESUMEN_COLS = [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];

export function normalizeCedula(s) {
  if (s == null) return "";
  return String(s).replace(/[^0-9A-Za-z]/g, "").toUpperCase();
}

export function clean(s) {
  if (s == null) return "";
  return String(s).trim();
}

export async function leerHoja(accessToken) {
  const headers = { Authorization: `Bearer ${accessToken}` };
  const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}`, { headers });
  if (!metaRes.ok) {
    const t = await metaRes.text();
    throw new Error("No se pudo acceder a la planilla: " + t);
  }
  const meta = await metaRes.json();
  const sheet = (meta.sheets || []).find(s => String(s.properties?.sheetId) === String(GID));
  const sheetTitle = sheet?.properties?.title;
  if (!sheetTitle) throw new Error("No se encontro la hoja con gid " + GID);
  const range = encodeURIComponent(sheetTitle);
  const valsRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${range}`, { headers });
  if (!valsRes.ok) {
    const t = await valsRes.text();
    throw new Error("No se pudo leer los datos: " + t);
  }
  const valsData = await valsRes.json();
  return valsData.values || [];
}

export function encontrarHeader(rows) {
  for (let r = 0; r < Math.min(rows.length, 10); r++) {
    const c = rows[r].findIndex(h => /c[eé]dula|documento|\bci\b/i.test(h || ""));
    if (c !== -1) return { headerIdx: r, cedulaCol: c };
  }
  return null;
}

export function parsearPersona(headerRow, dataRow) {
  const get = (idx) => clean(dataRow[idx]);
  const grado = get(2);
  const nombre = get(3);
  const apellido = get(4);
  const documento = get(5);
  const fuerza = get(6);
  const unidad = get(7);
  const edadRaw = get(8);
  // Col 16: "Voluntario a participar de la M.S.P.M." -> "Voluntario" | "No Voluntario"
  const voluntario = get(15);
  // Col 19: "Tipo de Reinstruccion a realizar:" -> "Modalidad Salto Caida Libre" | "Modalidad Salto Semi-automatico"
  const tipoReinstruccion = get(18);
  const nombreCompleto = [grado, nombre, apellido].map(clean).filter(Boolean).join(" ");
  const edadMatch = edadRaw.match(/\d+/);
  const edad = edadMatch ? Number(edadMatch[0]) : null;
  return {
    grado,
    nombre,
    apellido,
    documento,
    fuerza,
    unidad,
    edad,
    nombreCompleto,
    voluntario,
    tipoReinstruccion
  };
}

export function construirResumen(headerRow, dataRow, cols = RESUMEN_COLS) {
  return cols.map(idx => ({
    label: clean(headerRow[idx]) || `Columna ${idx}`,
    value: clean(dataRow[idx]) || ""
  })).filter(item => item.label);
}
// Hora del servidor. Se usa para sincronizar el cronometro de la carrera
// entre el encargado de estacion, los evaluadores auxiliares y la vista en vivo.
export default async function (req) {
  try {
    return Response.json({ now: new Date().toISOString() });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
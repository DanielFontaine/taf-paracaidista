import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { normalizeCedula, leerHoja, encontrarHeader, parsearPersona, construirResumen } from '../../shared/postulantes-sheet.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json().catch(() => ({}));
    const cedula = normalizeCedula(body?.cedula);
    if (!cedula) return Response.json({ error: "Cedula requerida" }, { status: 400 });

    const { accessToken } = await base44.asServiceRole.connectors.getConnection("googlesheets");
    const rows = await leerHoja(accessToken);
    if (rows.length < 2) return Response.json({ encontrada: false });

    const headerInfo = encontrarHeader(rows);
    if (!headerInfo) return Response.json({ error: "No se encontro una columna de cedula en la planilla" }, { status: 504 });
    const { headerIdx, cedulaCol } = headerInfo;
    const headerRow = rows[headerIdx];

    let matchedRow = null;
    for (let i = headerIdx + 1; i < rows.length; i++) {
      if (normalizeCedula(rows[i][cedulaCol]) === cedula) { matchedRow = rows[i]; break; }
    }
    if (!matchedRow) return Response.json({ encontrada: false });

    const persona = parsearPersona(headerRow, matchedRow);
    const resumen = construirResumen(headerRow, matchedRow);
    return Response.json({ encontrada: true, ...persona, resumen });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
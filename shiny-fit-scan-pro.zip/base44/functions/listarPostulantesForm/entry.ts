import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { clean, leerHoja, encontrarHeader, parsearPersona } from '../../shared/postulantes-sheet.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    const { accessToken } = await base44.asServiceRole.connectors.getConnection("googlesheets");
    const rows = await leerHoja(accessToken);
    if (rows.length < 2) return Response.json({ postulantes: [] });

    const headerInfo = encontrarHeader(rows);
    if (!headerInfo) return Response.json({ error: "No se encontro una columna de cedula" }, { status: 504 });
    const { headerIdx, cedulaCol } = headerInfo;
    const headerRow = rows[headerIdx];

    const postulantes = [];
    for (let i = headerIdx + 1; i < rows.length; i++) {
      const row = rows[i];
      const doc = clean(row[cedulaCol]);
      if (!doc) continue;
      const persona = parsearPersona(headerRow, row);
      if (persona.documento) postulantes.push(persona);
    }
    return Response.json({ postulantes });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
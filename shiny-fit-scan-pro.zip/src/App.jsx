import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { RoleProvider } from './lib/RoleContext';
// Add page imports here
import Home from './pages/Home';
import ParticipanteConsulta from './pages/ParticipanteConsulta';
import EvaluadorMenu from './pages/EvaluadorMenu';
import EvaluadorForm from './pages/EvaluadorForm';
import Reinstruccion from './pages/Reinstruccion';
import CentroComputos from './pages/CentroComputos';
import RegistroParticipante from './pages/RegistroParticipante';
import ControlAptoMedico from './pages/ControlAptoMedico';
import LimpiadorQR from './pages/LimpiadorQR';
import CarreraMenu from './pages/CarreraMenu';
import CarreraEncargado from './pages/CarreraEncargado';
import CarreraAuxiliar from './pages/CarreraAuxiliar';
import CarreraLive from './pages/CarreraLive';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  // Ruta publica: la consulta del participante (acceso por cedula) no requiere login.
  if (location.pathname === '/participante' || location.pathname === '/carrera-live') {
    return (
      <Routes>
        <Route path="/participante" element={<ParticipanteConsulta />} />
        <Route path="/carrera-live" element={<CarreraLive />} />
      </Routes>
    );
  }

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      {/* Add your page Route elements here */}
      <Route path="/" element={<Home />} />
      <Route path="/participante" element={<ParticipanteConsulta />} />
      <Route path="/evaluador" element={<EvaluadorMenu />} />
      <Route path="/evaluador/cargar/:disciplina" element={<EvaluadorForm />} />
      <Route path="/evaluador/carrera" element={<CarreraMenu />} />
      <Route path="/evaluador/carrera/encargado" element={<CarreraEncargado />} />
      <Route path="/evaluador/carrera/auxiliar" element={<CarreraAuxiliar />} />
      <Route path="/carrera-live" element={<CarreraLive />} />
      <Route path="/reinstruccion" element={<Reinstruccion />} />
      <Route path="/centro" element={<CentroComputos />} />
      <Route path="/registro-participante" element={<RegistroParticipante />} />
      <Route path="/control-apto-medico" element={<ControlAptoMedico />} />
      <Route path="/limpiador-qr" element={<LimpiadorQR />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <RoleProvider>
            <AuthenticatedApp />
          </RoleProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
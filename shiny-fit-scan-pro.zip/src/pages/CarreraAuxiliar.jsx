import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import TimerDisplay from "@/components/carrera/TimerDisplay";
import ListaCorredores from "@/components/carrera/ListaCorredores";
import FormParticipante from "@/components/carrera/FormParticipante";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";
import { getSesion, nuevoId, setSesion } from "@/lib/carrera-utils";
import { syncServerClock, serverNow, useCronometro } from "@/hooks/useCronometro";
import { useParticipantesCarrera } from "@/hooks/useParticipantesCarrera";
import { PIN_EVALUADOR } from "@/lib/postulantes-utils";

const KEY_NOMBRE = "carrera_evaluador";
const KEY_ID = "carrera_evaluador_id";
const KEY_AC = "carrera_auxiliar";

// Evaluador auxiliar: se vincula a la carrera con el codigo del encargado,
// ingresa participantes y detiene el tiempo de cada uno en la meta.
export default function CarreraAuxiliar() {
  const navigate = useNavigate();

  const [evaluadorId] = useState(() => {
    const guardado = getSesion(KEY_ID);
    if (guardado) return guardado;
    const id = nuevoId();
    setSesion(KEY_ID, id);
    return id;
  });
  const [nombre, setNombre] = useState(() => getSesion(KEY_NOMBRE) || "");
  const [carrera, setCarrera] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [codigo, setCodigo] = useState("");
  const [msg, setMsg] = useState("");
  const [uniendo, setUniendo] = useState(false);
  const [mostrarForm, setMostrarForm] = useState(false);

  useEffect(() => {
    syncServerClock();
    const guardada = getSesion(KEY_AC);
    if (guardada?.id) {
      base44.entities.Carrera.get(guardada.id)
        .then((c) => setCarrera(c))
        .catch(() => setSesion(KEY_AC, null))
        .finally(() => setCargando(false));
    } else {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    if (!carrera?.id) return;
    const unsubscribe = base44.entities.Carrera.subscribe((event) => {
      if (event?.data?.id === carrera.id) setCarrera(event.data);
    });
    return () => { if (typeof unsubscribe === "function") unsubscribe(); };
  }, [carrera?.id]);

  const participantes = useParticipantesCarrera(carrera?.id, evaluadorId);
  const activo = carrera?.Estado === "en_curso";
  const segundos = useCronometro(carrera?.Inicio, activo);

  const unirse = async (e) => {
    e.preventDefault();
    const nom = nombre.trim();
    const cod = codigo.replace(/\D/g, "").slice(0, 3);
    if (!nom) {
      setMsg("Ingrese su nombre.");
      return;
    }
    if (cod.length !== 3) {
      setMsg("Ingrese el codigo de 3 digitos.");
      return;
    }
    setUniendo(true);
    setMsg("");
    try {
      const { items } = await base44.entities.Carrera.filter({ Codigo: cod }, { sort: "-created_date", limit: 20 });
      const abierta = (items || []).find((c) => c.Estado !== "finalizada");
      if (!abierta) {
        setMsg("No hay una carrera activa con ese codigo.");
        return;
      }
      setSesion(KEY_NOMBRE, nom);
      setSesion(KEY_AC, { id: abierta.id });
      setCarrera(abierta);
    } catch (err) {
      setMsg("No se pudo vincular a la carrera.");
    } finally {
      setUniendo(false);
    }
  };

  const detener = async (p) => {
    if (!activo || !carrera?.Inicio) return;
    const tiempo = Math.round((serverNow() - Date.parse(carrera.Inicio)) / 1000);
    const hora = new Date().toISOString();
    try {
      await base44.entities.CarreraParticipante.update(p.id, {
        Tiempo: tiempo,
        Estado: "finalizado",
        Hora_Llegada: hora,
      });
      await base44.entities.Evaluacion.create({
        ID_NFC: p.ID_NFC,
        Disciplina: "Carrera",
        Resultado: tiempo,
        Distancia: p.Distancia,
        Fecha_Hora: hora,
        PIN_Instructor: PIN_EVALUADOR,
      });
    } catch (e) {
      setMsg("No se pudo registrar el tiempo.");
    }
  };

  const salir = () => {
    setSesion(KEY_AC, null);
    setCarrera(null);
    setMostrarForm(false);
    setMsg("");
  };

  const finalizados = participantes.filter((p) => p.Estado === "finalizado").length;
  const evaluacionFinalizada = participantes.length > 0 && finalizados === participantes.length;

  return (
    <AppShell title="Evaluador Auxiliar" subtitle="Carrera" onBack={() => navigate("/evaluador/carrera")} accent="emerald">
      {cargando && <p className="text-sm text-slate-500 text-center py-8 animate-pulse">Cargando…</p>}

      {!cargando && !carrera && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="text-center mb-5">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-sky-50 mb-3">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#0284c7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M19 8v6M22 11h-6" />
              </svg>
            </div>
            <h2 className="font-semibold text-slate-800">Agregarse a nueva carrera</h2>
            <p className="text-sm text-slate-500 mt-1">Ingrese su nombre y el codigo que le dio el encargado de la estacion</p>
          </div>

          <form onSubmit={unirse} className="space-y-3">
            <div>
              <label className="text-sm font-medium text-slate-700">Nombre del evaluador</label>
              <Input
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Nombre y apellido"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slate-700">Codigo de la carrera</label>
              <Input
                value={codigo}
                onChange={(e) => setCodigo(e.target.value.replace(/\D/g, "").slice(0, 3))}
                inputMode="numeric"
                placeholder="000"
                className="mt-1 text-center text-3xl font-mono tracking-[0.4em]"
              />
            </div>
            {msg && <p className="text-sm text-red-600">{msg}</p>}
            <Button type="submit" disabled={uniendo} className="w-full h-12 text-base">
              {uniendo ? "Vinculando…" : "Vincularme a la carrera"}
            </Button>
          </form>
        </div>
      )}

      {carrera && (
        <div className="space-y-4">
          <div className="bg-gradient-to-br from-sky-600 to-sky-800 text-white rounded-2xl p-5 shadow-lg flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-white/70">Carrera</p>
              <p className="text-3xl font-extrabold tracking-[0.2em] tabular-nums">{carrera.Codigo}</p>
              <p className="text-xs text-white/80 mt-1">{nombre}</p>
            </div>
            <div className="text-right">
              {carrera.Estado === "espera" && <p className="text-sm font-semibold text-white/90">Esperando inicio…</p>}
              {activo && <TimerDisplay segundos={segundos} size="md" className="text-white" />}
              {carrera.Estado === "finalizada" && <p className="text-sm font-semibold text-white/90">Carrera finalizada</p>}
            </div>
          </div>

          {!mostrarForm && (
            <Button
              onClick={() => setMostrarForm(true)}
              disabled={carrera.Estado === "finalizada"}
              className="w-full h-12 text-base"
            >
              Ingresar nuevo participante
            </Button>
          )}

          {mostrarForm && (
            <FormParticipante
              carrera={carrera}
              evaluador={{ id: evaluadorId, nombre }}
              onAdded={() => setMostrarForm(false)}
            />
          )}

          {evaluacionFinalizada && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-4 flex items-center gap-3">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
              <div>
                <p className="text-sm font-semibold">Evaluacion finalizada</p>
                <p className="text-xs text-emerald-700">Todos los participantes tienen su tiempo registrado.</p>
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-800">Mis participantes</h3>
              <span className="text-xs font-semibold text-slate-500">{finalizados}/{participantes.length}</span>
            </div>
            {activo && !evaluacionFinalizada && (
              <p className="text-xs text-amber-600 mb-2">Toque el nombre del corredor cuando cruce la meta para detener su tiempo.</p>
            )}
            <ListaCorredores
              items={participantes}
              onSelect={detener}
              puedeDetener={activo}
              emptyMsg="Aun no ingreso participantes."
            />
          </div>

          {msg && <p className="text-sm text-red-600">{msg}</p>}

          <Button variant="outline" className="w-full" onClick={salir}>
            Salir de la carrera
          </Button>
        </div>
      )}
    </AppShell>
  );
}
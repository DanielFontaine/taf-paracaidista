import React, { useEffect, useState } from "react";
import TimerDisplay from "@/components/carrera/TimerDisplay";
import { base44 } from "@/api/base44Client";
import { formatTiempo } from "@/lib/carrera-utils";
import { syncServerClock, useCronometro } from "@/hooks/useCronometro";
import { useParticipantesCarrera } from "@/hooks/useParticipantesCarrera";

// Vista publica para proyectar la carrera en una pantalla: cronometro en vivo
// y tiempos a medida que los corredores llegan a la meta.
export default function CarreraLive() {
  const [codigo, setCodigo] = useState("");
  const [carrera, setCarrera] = useState(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    syncServerClock();
    const params = new URLSearchParams(window.location.search);
    setCodigo((params.get("codigo") || "").trim());
  }, []);

  useEffect(() => {
    let vigente = true;
    const cargar = async () => {
      setCargando(true);
      try {
        let encontrada = null;
        if (codigo) {
          const { items } = await base44.entities.Carrera.filter({ Codigo: codigo }, { sort: "-created_date", limit: 20 });
          const lista = items || [];
          encontrada = lista.find((c) => c.Estado === "en_curso") || lista[0] || null;
        } else {
          const { items } = await base44.entities.Carrera.filter(
            { Estado: { $in: ["en_curso", "espera"] } },
            { sort: "-created_date", limit: 1 }
          );
          encontrada = items?.[0] || null;
        }
        if (vigente) setCarrera(encontrada);
      } finally {
        if (vigente) setCargando(false);
      }
    };
    cargar();
    return () => { vigente = false; };
  }, [codigo]);

  useEffect(() => {
    if (!carrera?.id) return;
    const unsubscribe = base44.entities.Carrera.subscribe((event) => {
      if (event?.data?.id === carrera.id) setCarrera(event.data);
    });
    return () => { if (typeof unsubscribe === "function") unsubscribe(); };
  }, [carrera?.id]);

  const participantes = useParticipantesCarrera(carrera?.id);
  const activo = carrera?.Estado === "en_curso";
  const segundos = useCronometro(carrera?.Inicio, activo);

  const finalizados = participantes
    .filter((p) => p.Estado === "finalizado")
    .sort((a, b) => (Number(a.Tiempo) || 0) - (Number(b.Tiempo) || 0));
  const enCarrera = participantes.length - finalizados.length;

  if (cargando) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!carrera) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center gap-2 px-8 text-center">
        <p className="text-2xl font-bold">Sin carrera activa</p>
        <p className="text-white/50">Abra esta pantalla con el enlace que genera el encargado de estacion.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      <header className="px-8 py-6 flex items-center justify-between border-b border-white/10">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-400">Carrera TAF · En vivo</p>
          <h1 className="text-3xl font-bold mt-1">Codigo {carrera.Codigo}</h1>
        </div>
        <div className="text-right">
          <p className="text-xs uppercase tracking-wider text-white/50">En meta</p>
          <p className="text-4xl font-bold tabular-nums">
            {finalizados.length}
            <span className="text-xl text-white/50">/{participantes.length}</span>
          </p>
        </div>
      </header>

      <section className="text-center py-8">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/50">Cronometro</p>
        <div className="mt-2">
          <TimerDisplay segundos={segundos} size="xl" className={activo ? "text-white" : "text-white/30"} />
        </div>
        {carrera.Estado === "espera" && <p className="text-white/60 mt-2">Esperando el inicio de la carrera</p>}
        {carrera.Estado === "finalizada" && <p className="text-white/60 mt-2">Carrera finalizada</p>}
      </section>

      <section className="flex-1 px-8 pb-10">
        <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-white/50 mb-3">Resultados</h2>
        {finalizados.length === 0 ? (
          <p className="text-white/40">Sin tiempos registrados todavia.</p>
        ) : (
          <ol className="space-y-2">
            {finalizados.map((p, i) => (
              <li
                key={p.id}
                className={`flex items-center gap-4 rounded-xl px-4 py-3 ${
                  i === 0 ? "bg-emerald-500/15 border border-emerald-500/40" : "bg-white/5"
                }`}
              >
                <span className="w-10 text-2xl font-extrabold text-white/40 tabular-nums">{i + 1}</span>
                <span className="w-12 text-lg font-bold text-white/70 tabular-nums">{p.Numero || "—"}</span>
                <span className="flex-1 text-2xl font-semibold truncate">{p.Nombre}</span>
                <span className="text-2xl font-extrabold text-emerald-400 tabular-nums">{formatTiempo(p.Tiempo)}</span>
              </li>
            ))}
          </ol>
        )}
        {enCarrera > 0 && <p className="text-white/40 mt-4">{enCarrera} aun en carrera</p>}
      </section>
    </div>
  );
}
import React from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";

// Submenu de la disciplina Carrera: encargado de estacion o evaluador auxiliar.
export default function CarreraMenu() {
  const navigate = useNavigate();

  const opciones = [
    {
      title: "Encargado de la Estacion",
      desc: "Crear la carrera, iniciar el cronometro y ver los resultados en vivo",
      dest: "/evaluador/carrera/encargado",
      accent: "from-emerald-600 to-emerald-800",
      icon: (
        <>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 3" />
        </>
      ),
    },
    {
      title: "Evaluador Auxiliar",
      desc: "Ingresar participantes y detener los tiempos en la meta",
      dest: "/evaluador/carrera/auxiliar",
      accent: "from-sky-600 to-sky-800",
      icon: (
        <>
          <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M19 8v6M22 11h-6" />
        </>
      ),
    },
  ];

  return (
    <AppShell title="Carrera" subtitle="TAF · Corrida" onBack={() => navigate("/evaluador")} accent="emerald">
      <div className="space-y-3">
        {opciones.map((o) => (
          <button
            key={o.dest}
            onClick={() => navigate(o.dest)}
            className={`group w-full text-left rounded-2xl p-5 text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-gradient-to-br ${o.accent}`}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  {o.icon}
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold tracking-tight">{o.title}</h3>
                <p className="text-sm text-white/80">{o.desc}</p>
              </div>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:translate-x-1 transition">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </div>
          </button>
        ))}
      </div>
    </AppShell>
  );
}
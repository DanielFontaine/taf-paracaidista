import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import CedulaAutocomplete from "@/components/CedulaAutocomplete";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { formatDocumento } from "@/lib/postulantes-utils";
import usePostulantesForm from "@/hooks/usePostulantesForm";

export default function RegistroParticipante() {
  const navigate = useNavigate();
  const [cedula, setCedula] = useState("");
  const [buscando, setBuscando] = useState(false);
  const [resumen, setResumen] = useState(null);
  const [noEncontrado, setNoEncontrado] = useState(false);
  const [msg, setMsg] = useState("");

  const [idNfc, setIdNfc] = useState("");
  const [nombre, setNombre] = useState("");
  const [edad, setEdad] = useState("");
  const [documento, setDocumento] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [ok, setOk] = useState(false);

  // Cedulas de la planilla del formulario para las sugerencias de busqueda.
  const postulantesForm = usePostulantesForm();

  const buscar = async (e) => {
    e.preventDefault();
    if (!cedula.trim()) return;
    setBuscando(true);
    setMsg("");
    setResumen(null);
    setNoEncontrado(false);
    setOk(false);
    try {
      const res = await base44.functions.invoke("buscarPostulanteForm", { cedula: cedula.trim() });
      const d = res.data;
      if (d?.encontrada) {
        setResumen(d.resumen || []);
        setNombre(d.nombreCompleto || "");
        setDocumento(String(d.documento || "").replace(/\D/g, ""));
        setEdad(d.edad != null ? String(d.edad) : "");
      } else if (d?.error) {
        setMsg(d.error);
      } else {
        setNoEncontrado(true);
      }
    } catch (err) {
      setMsg("Error al buscar en el formulario.");
    } finally {
      setBuscando(false);
    }
  };

  const guardar = async (e) => {
    e.preventDefault();
    setMsg("");
    setOk(false);
    if (idNfc.trim().length !== 3) { setMsg("Ingrese los 3 digitos del codigo QR."); return; }
    if (!nombre.trim()) { setMsg("Falta el nombre."); return; }
    setGuardando(true);
    try {
      const idUpper = "QR-" + idNfc.trim();
      const doc = String(documento).replace(/\D/g, "");
      // verificar si el codigo QR ya esta asignado a otra persona
      const porNfc = await base44.entities.Postulante.filter({ ID_NFC: idUpper });
      if (porNfc && porNfc.length > 0) {
        setMsg(`El codigo QR ${idUpper} ya esta asignado a otra persona (${porNfc[0].Nombre_Completo}).`);
        return;
      }
      // verificar si esta persona ya tiene un codigo QR asignado
      if (doc) {
        const porDoc = await base44.entities.Postulante.filter({ Documento: doc });
        if (porDoc && porDoc.length > 0) {
          setMsg(`Esta persona ya tiene un codigo QR asignado (${porDoc[0].ID_NFC}).`);
          return;
        }
      }
      await base44.entities.Postulante.create({
        ID_NFC: idUpper,
        Nombre_Completo: nombre.trim(),
        Documento: doc,
        Edad: edad ? Number(edad) : undefined,
      });
      setOk(true);
      setIdNfc(""); setNombre(""); setEdad(""); setDocumento("");
    } catch (err) {
      setMsg("No se pudo registrar el postulante.");
    } finally {
      setGuardando(false);
    }
  };

  const registrarOtro = () => {
    setOk(false);
    setMsg("");
    setCedula("");
    setResumen(null);
    setTimeout(() => document.querySelector('input[placeholder="Cedula"]')?.focus(), 50);
  };

  return (
    <AppShell title="Registro de Participante" subtitle="Buscar en formulario y registrar" onBack={() => navigate("/")} accent="emerald">
      <form onSubmit={buscar} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-4">
        <h2 className="font-semibold text-slate-800 mb-1">Buscar postulante</h2>
        <p className="text-sm text-slate-500 mb-4">Ingrese el numero de cedula del postulante</p>
        <div className="flex gap-2">
          <CedulaAutocomplete
            value={cedula}
            onChange={setCedula}
            postulantes={postulantesForm}
            placeholder="Cedula"
            autoFocus
          />
          <Button type="submit" disabled={buscando || !cedula.trim()}>
            {buscando ? "Buscando…" : "Buscar"}
          </Button>
        </div>
        {msg && !resumen && <p className="text-sm text-red-600 mt-3">{msg}</p>}
        {noEncontrado && (
          <p className="text-sm text-amber-700 mt-3 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            No se encontro un postulante con esa cedula en el formulario.
          </p>
        )}
      </form>

      {resumen && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-4">
          <h3 className="font-semibold text-slate-800 mb-1">Datos del formulario</h3>
          <p className="text-xs text-slate-500 mb-3">Verifique que sea la persona correcta:</p>
          <dl className="space-y-2">
            {resumen.map((item, i) => (
              <div key={i} className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2 border-b border-slate-100 pb-2">
                <dt className="text-sm font-medium text-slate-500 sm:w-2/5">{item.label}</dt>
                <dd className="text-sm text-slate-800 font-semibold flex-1 break-words">{item.value || "—"}</dd>
              </div>
            ))}
          </dl>
        </div>
      )}

      {resumen && (
        <form onSubmit={guardar} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="font-semibold text-slate-800 mb-1">Registrar codigo QR</h3>
          <p className="text-sm text-slate-500 mb-4">Ingrese el numero del codigo QR manualmente</p>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-500">Numero de codigo QR</label>
              <div className="relative mt-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm pointer-events-none">QR-</span>
                <Input
                  value={idNfc}
                  onChange={(e) => setIdNfc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                  placeholder="001"
                  inputMode="numeric"
                  maxLength={3}
                  className="pl-12 font-mono"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500">Nombre completo</label>
              <Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-500">Documento</label>
                <Input value={formatDocumento(documento)} readOnly className="mt-1 bg-slate-50" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500">Edad</label>
                <Input value={edad} onChange={(e) => setEdad(e.target.value)} inputMode="numeric" className="mt-1" />
              </div>
            </div>
          </div>
          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
          {ok ? (
            <div className="mt-4 space-y-3">
              <div className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 font-medium">
                Registrado con exito.
              </div>
              <Button type="button" className="w-full" onClick={registrarOtro}>
                Registrar otro participante
              </Button>
            </div>
          ) : (
            <Button type="submit" className="w-full mt-4" disabled={guardando}>
              {guardando ? "Guardando…" : "Registrar postulante"}
            </Button>
          )}
        </form>
      )}
    </AppShell>
  );
}
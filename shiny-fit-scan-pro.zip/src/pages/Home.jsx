import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import { PIN_EVALUADOR, PIN_CENTRO, PIN_REINSTRUCCION, PIN_REGISTRO, PIN_APTO, PIN_LIMPIADOR } from "@/lib/postulantes-utils";
import { useRole } from "@/lib/RoleContext";

const LOGO_CIPPOEEEE = "https://media.base44.com/images/public/6a720efa4edfec96e6684a30/16116e20a_images.png";

// Pantalla inicial: botones de acceso por rol.
// El PIN se pide una sola vez; el rol queda memorizado en la sesion.
// El rol "centro" habilita acceso a cualquier parte de la app.
export default function Home() {
  const navigate = useNavigate();
  const { role, setRole } = useRole();
  const [pinPrompt, setPinPrompt] = useState(null); // 'evaluador' | 'reinstruccion' | 'centro' | null
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");

  const openPrompt = (target) => {
    // Si ya esta autorizado para ese destino, no volver a pedir PIN.
    if (target === "evaluador" && (role === "evaluador" || role === "centro")) {
      navigate("/evaluador");
      return;
    }
    if (target === "reinstruccion" && (role === "reinstruccion" || role === "centro")) {
      navigate("/reinstruccion");
      return;
    }
    if (target === "centro" && role === "centro") {
      navigate("/centro");
      return;
    }
    if (target === "registro" && (role === "registro" || role === "centro")) {
      navigate("/registro-participante");
      return;
    }
    if (target === "apto" && (role === "apto" || role === "centro")) {
      navigate("/control-apto-medico");
      return;
    }
    if (target === "limpiador" && (role === "limpiador" || role === "centro")) {
      navigate("/limpiador-qr");
      return;
    }
    setPinPrompt(target);
    setPin("");
    setErr("");
  };

  const validatePin = (e) => {
    e.preventDefault();
    const map = {
      evaluador: { pin: PIN_EVALUADOR, role: "evaluador", dest: "/evaluador" },
      reinstruccion: { pin: PIN_REINSTRUCCION, role: "reinstruccion", dest: "/reinstruccion" },
      centro: { pin: PIN_CENTRO, role: "centro", dest: "/centro" },
      registro: { pin: PIN_REGISTRO, role: "registro", dest: "/registro-participante" },
      apto: { pin: PIN_APTO, role: "apto", dest: "/control-apto-medico" },
      limpiador: { pin: PIN_LIMPIADOR, role: "limpiador", dest: "/limpiador-qr" },
    };
    const cfg = map[pinPrompt];
    if (cfg && pin === cfg.pin) {
      setRole(cfg.role);
      setPinPrompt(null);
      setPin("");
      navigate(cfg.dest);
    } else {
      setErr("PIN incorrecto.");
    }
  };

  const RoleCard = ({ title, desc, icon, accent, onClick }) => (
    <button
      onClick={onClick}
      className={`group relative w-full text-left rounded-2xl p-6 text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 overflow-hidden ${accent}`}
    >
      <div className="absolute -right-6 -top-6 opacity-20 group-hover:opacity-30 transition">{icon}</div>
      <div className="relative">
        <h3 className="text-lg font-bold tracking-tight">{title}</h3>
        <p className="text-sm text-white/80 mt-1">{desc}</p>
      </div>
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-slate-200 flex flex-col">
      <header className="bg-slate-900 text-white">
        <div className="max-w-md mx-auto px-5 py-8 text-center">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-white/10 mb-4 overflow-hidden ring-2 ring-white/20">
            <Image
              src={LOGO_CIPPOEEEE}
              fittingType="fit"
              className="w-full h-full"
              alt="C.I.PP.OO.EE.E. Uruguay"
            />
          </div>
          <h1 className="text-xl font-bold tracking-tight leading-snug px-2">
            PLATAFORMA DE REGISTRO DE TAF PARACAIDISTA
          </h1>
        </div>
      </header>

      <main className="flex-1 max-w-md w-full mx-auto px-5 py-8 space-y-4">
        <p className="text-center text-xs font-semibold tracking-widest text-slate-500 uppercase mb-2">Menu Principal</p>

        <RoleCard
          title="Participante"
          desc="Consulte sus resultados ingresando su cedula"
          accent="bg-gradient-to-br from-blue-600 to-blue-800"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg>}
          onClick={() => { setRole("participante"); navigate("/participante"); }}
        />

        <RoleCard
          title="Evaluador de TAF"
          desc="Carga de repeticiones y tiempos por estacion"
          accent="bg-gradient-to-br from-amber-500 to-amber-700"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M9 11l3 3 7-7"/><path d="M21 12a9 9 0 11-9-9"/></svg>}
          onClick={() => openPrompt("evaluador")}
        />

        <RoleCard
          title="Reinstruccion Tecnica"
          desc="Marcar asistencia por estacion de instruccion"
          accent="bg-gradient-to-br from-violet-600 to-violet-800"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>}
          onClick={() => openPrompt("reinstruccion")}
        />

        <RoleCard
          title="Registro de Participante"
          desc="Buscar por cedula en el formulario y registrar codigo QR"
          accent="bg-gradient-to-br from-cyan-600 to-cyan-800"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>}
          onClick={() => openPrompt("registro")}
        />

        <RoleCard
          title="Control Apto Medico"
          desc="Validar apto medico por cedula del postulante"
          accent="bg-gradient-to-br from-rose-500 to-rose-700"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0016.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 002 8.5c0 2.29 1.51 4.04 3 5.5l7 7 7-7z"/><path d="M12 9v4M12 17h.01"/></svg>}
          onClick={() => openPrompt("apto")}
        />

        <RoleCard
          title="Centro de Computos"
          desc="Gestion de postulantes y seguimiento del evento"
          accent="bg-gradient-to-br from-emerald-600 to-emerald-800"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>}
          onClick={() => openPrompt("centro")}
        />

        <RoleCard
          title="Limpiador de QR"
          desc="Liberar un codigo QR para asignarlo a un nuevo postulante"
          accent="bg-gradient-to-br from-slate-600 to-slate-800"
          icon={<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M21 14v7M14 21h3"/></svg>}
          onClick={() => openPrompt("limpiador")}
        />
      </main>

      {pinPrompt && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-5 z-50" onClick={() => setPinPrompt(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-xs shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 text-center">
              {pinPrompt === "evaluador" ? "Acceso Evaluador de TAF" : pinPrompt === "reinstruccion" ? "Acceso Reinstruccion Tecnica" : pinPrompt === "registro" ? "Acceso Registro de Participante" : pinPrompt === "apto" ? "Acceso Control Apto Medico" : pinPrompt === "limpiador" ? "Acceso Limpiador de QR" : "Acceso Centro de Computos"}
            </h3>
            <p className="text-sm text-slate-500 text-center mt-1 mb-4">Ingrese el PIN</p>
            <form onSubmit={validatePin} className="space-y-3">
              <Input
                type="password"
                inputMode="numeric"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="••••"
                className="text-center text-2xl tracking-[0.5em]"
                autoFocus
              />
              {err && <p className="text-sm text-red-600 text-center">{err}</p>}
              <div className="flex gap-2">
                <Button type="button" variant="secondary" className="flex-1" onClick={() => setPinPrompt(null)}>Cancelar</Button>
                <Button type="submit" className="flex-1">Ingresar</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
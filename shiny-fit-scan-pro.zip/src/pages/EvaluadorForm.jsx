import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import QrScanner from "@/components/QrScanner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { base44 } from "@/api/base44Client";
import { PIN_EVALUADOR, formatDocumento } from "@/lib/postulantes-utils";

// Formulario de carga de evaluacion por disciplina.
// El PIN del evaluador se valida una sola vez en Home; aqui la carga es libre.
export default function EvaluadorForm() {
  const { disciplina } = useParams();
  const navigate = useNavigate();
  const Disciplina = disciplina
    ? disciplina.charAt(0).toUpperCase() + disciplina.slice(1)
    : "Barras";

  const isCarrera = Disciplina === "Carrera";

  const [postulante, setPostulante] = useState(null);
  const [finding, setFinding] = useState(false);
  const [msg, setMsg] = useState("");

  const [resultado, setResultado] = useState(0);
  const [minutos, setMinutos] = useState(0);
  const [segundos, setSegundos] = useState(0);
  const [distancia, setDistancia] = useState(3000);
  const [ejercicio, setEjercicio] = useState("Barras");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const handleScan = async (idNfc) => {
    setFinding(true);
    setMsg("");
    setPostulante(null);
    setDone(false);
    try {
      const matches = await base44.entities.Postulante.filter({ ID_NFC: idNfc });
      if (!matches || matches.length === 0) {
        setMsg("No se encontro un postulante con ese codigo QR.");
        return;
      }
      const existentes = await base44.entities.Evaluacion.filter({ ID_NFC: idNfc, Disciplina });
      if (existentes && existentes.length > 0) {
        setMsg("Este postulante ya tiene registrada la disciplina " + Disciplina + ".");
        return;
      }
      setPostulante(matches[0]);
    } catch (e) {
      setMsg("Error al buscar el postulante.");
    } finally {
      setFinding(false);
    }
  };

  const guardar = async (e) => {
    e.preventDefault();
    let val;
    if (isCarrera) {
      val = Number(minutos) * 60 + Number(segundos);
      if (val <= 0) {
        setMsg("Ingrese un tiempo valido.");
        return;
      }
    } else {
      val = Number(resultado);
      if (isNaN(val) || val < 0) {
        setMsg("Ingrese un resultado valido.");
        return;
      }
    }
    setSaving(true);
    setMsg("");
    try {
      await base44.entities.Evaluacion.create({
        ID_NFC: postulante.ID_NFC,
        Disciplina,
        Resultado: val,
        Distancia: isCarrera ? Number(distancia) : undefined,
        Ejercicio: Disciplina === "Barras" ? ejercicio : undefined,
        Fecha_Hora: new Date().toISOString(),
        PIN_Instructor: PIN_EVALUADOR,
      });
      setDone(true);
      setPostulante(null);
      setResultado(0);
      setMinutos(0);
      setSegundos(0);
      setDistancia(3000);
      setEjercicio("Barras");
    } catch (err) {
      setMsg("No se pudo guardar la evaluacion.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppShell title={`Cargar · ${Disciplina.toUpperCase()}`} subtitle="Estacion de evaluacion" onBack={() => navigate("/evaluador")} accent="amber">
      {done && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-4 mb-4 flex items-center gap-3">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
          <p className="text-sm font-medium">Evaluacion registrada correctamente.</p>
        </div>
      )}

      {!postulante && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h2 className="font-semibold text-slate-800 mb-1">Postulante</h2>
          <p className="text-sm text-slate-500 mb-4">Escanee el codigo QR del postulante</p>
          <QrScanner onScan={handleScan} label="Escanear QR del postulante" />
          {finding && <p className="text-sm text-blue-600 mt-3 animate-pulse">Buscando…</p>}
          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
        </div>
      )}

      {postulante && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Postulante</p>
            <h2 className="text-lg font-bold text-slate-900 mt-0.5">{postulante.Nombre_Completo}</h2>
            <p className="text-sm text-slate-500">Doc: {formatDocumento(postulante.Documento)}</p>
            <button onClick={() => { setPostulante(null); setMsg(""); }} className="text-xs text-amber-600 mt-2 font-medium">
              Cambiar postulante
            </button>
          </div>

          <form onSubmit={guardar} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            {Disciplina === "Barras" && (
              <div>
                <label className="text-sm font-medium text-slate-700">Ejercicio</label>
                <p className="text-xs text-slate-500 mb-2">Seleccione el tipo de ejercicio realizado</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { v: "Barras", label: "Barras" },
                    { v: "Flexiones", label: "Flexiones de brazo" },
                  ].map((o) => (
                    <button
                      key={o.v}
                      type="button"
                      onClick={() => setEjercicio(o.v)}
                      className={`rounded-xl py-3 text-sm font-semibold border transition ${
                        ejercicio === o.v
                          ? "bg-slate-800 text-white border-slate-800 shadow"
                          : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {isCarrera && (
              <div>
                <label className="text-sm font-medium text-slate-700">Distancia</label>
                <p className="text-xs text-slate-500 mb-2">Seleccione la distancia recorrida</p>
                <div className="grid grid-cols-3 gap-2">
                  {[3200, 3000, 2800].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDistancia(d)}
                      className={`rounded-xl py-3 text-sm font-semibold border transition ${
                        Number(distancia) === d
                          ? "bg-emerald-600 text-white border-emerald-600 shadow"
                          : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                      }`}
                    >
                      {d} m
                    </button>
                  ))}
                </div>
              </div>
            )}
            {isCarrera ? (
              <div>
                <label className="text-sm font-medium text-slate-700">Tiempo</label>
                <p className="text-xs text-slate-500 mb-2">Minutos y segundos de la carrera</p>
                <div className="flex items-end gap-3">
                  <div className="flex-1">
                    <Input
                      type="number"
                      min="0"
                      value={minutos}
                      onChange={(e) => setMinutos(e.target.value)}
                      placeholder="0"
                      className="text-2xl font-semibold text-center"
                      autoFocus
                    />
                    <p className="text-xs text-slate-500 text-center mt-1">minutos</p>
                  </div>
                  <span className="text-2xl font-bold text-slate-400 pb-6">:</span>
                  <div className="flex-1">
                    <Input
                      type="number"
                      min="0"
                      max="59"
                      value={segundos}
                      onChange={(e) => setSegundos(e.target.value)}
                      placeholder="0"
                      className="text-2xl font-semibold text-center"
                    />
                    <p className="text-xs text-slate-500 text-center mt-1">segundos</p>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <label className="text-sm font-medium text-slate-700">Repeticiones</label>
                <p className="text-xs text-slate-500 mb-3">Deslice para seleccionar</p>
                <div className="flex items-center gap-4">
                  <Slider
                    value={[Number(resultado) || 0]}
                    onValueChange={([v]) => setResultado(v)}
                    min={0}
                    max={Disciplina === "Abdominales" ? 80 : 50}
                    step={1}
                    className="flex-1"
                  />
                  <span className="text-3xl font-bold text-slate-900 w-14 text-center tabular-nums">
                    {Number(resultado) || 0}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-2 text-center">
                  Rango: 0 a {Disciplina === "Abdominales" ? 80 : 50}
                </p>
              </div>
            )}
            {msg && <p className="text-sm text-red-600">{msg}</p>}
            <Button type="submit" disabled={saving} className="w-full">
              {saving ? "Guardando…" : "Guardar evaluacion"}
            </Button>
          </form>
        </div>
      )}
    </AppShell>
  );
}
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import TimerDisplay from "@/components/carrera/TimerDisplay";
import ListaCorredores from "@/components/carrera/ListaCorredores";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { generarCodigo, getSesion, setSesion } from "@/lib/carrera-utils";
import { syncServerClock, serverNow, useCronometro } from "@/hooks/useCronometro";
import { useParticipantesCarrera } from "@/hooks/useParticipantesCarrera";

const SESION_KEY = "carrera_encargado";

// Encargado de estacion: crea la carrera, comparte el codigo, inicia el
// cronometro y sigue en vivo a los participantes y sus tiempos.
export default function CarreraEncargado() {
  const navigate = useNavigate();
  const [carrera, setCarrera] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [creando, setCreando] = useState(false);
  const [msg, setMsg] = useState("");
  const [copiado, setCopiado] = useState(false);

  useEffect(() => {
    syncServerClock();
    const guardada = getSesion(SESION_KEY);
    if (guardada?.id) {
      base44.entities.Carrera.get(guardada.id)
        .then((c) => setCarrera(c))
        .catch(() => setSesion(SESION_KEY, null))
        .finally(() => setCargando(false));
    } else {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    if (!carrera?.id) return;
    const unsubscribe = base44.entities.Carrera.subscribe((event) => {
      if (event?.data?.id === carrera.id) setCarrera(event.data);
    });
    return () => { if (typeof unsubscribe === "function") unsubscribe(); };
  }, [carrera?.id]);

  const participantes = useParticipantesCarrera(carrera?.id);
  const activo = carrera?.Estado === "en_curso";
  const segundos = useCronometro(carrera?.Inicio, activo);

  const nuevaCarrera = async () => {
    setCreando(true);
    setMsg("");
    try {
      const c = await base44.entities.Carrera.create({ Codigo: generarCodigo(), Estado: "espera" });
      setSesion(SESION_KEY, { id: c.id });
      setCarrera(c);
    } catch (e) {
      setMsg("No se pudo crear la carrera.");
    } finally {
      setCreando(false);
    }
  };

  const iniciarCronometro = async () => {
    setMsg("");
    try {
      const inicio = new Date(serverNow()).toISOString();
      const c = await base44.entities.Carrera.update(carrera.id, { Estado: "en_curso", Inicio: inicio });
      setCarrera(c);
    } catch (e) {
      setMsg("No se pudo iniciar el cronometro.");
    }
  };

  const finalizarCarrera = async () => {
    setMsg("");
    try {
      const c = await base44.entities.Carrera.update(carrera.id, { Estado: "finalizada" });
      setCarrera(c);
    } catch (e) {
      setMsg("No se pudo finalizar la carrera.");
    }
  };

  const cerrarSesion = () => {
    setSesion(SESION_KEY, null);
    setCarrera(null);
  };

  const copiarEnlace = async () => {
    try {
      await navigator.clipboard.writeText(liveUrl);
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2000);
    } catch (e) {
      setMsg("No se pudo copiar el enlace.");
    }
  };

  const liveUrl = carrera ? `${window.location.origin}/carrera-live?codigo=${carrera.Codigo}` : "";
  const finalizados = participantes.filter((p) => p.Estado === "finalizado").length;

  return (
    <AppShell title="Encargado de Estacion" subtitle="Carrera" onBack={() => navigate("/evaluador/carrera")} accent="emerald">
      {cargando && <p className="text-sm text-slate-500 text-center py-8 animate-pulse">Cargando…</p>}

      {!cargando && !carrera && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-50 mb-3">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 7v5l3 3" />
            </svg>
          </div>
          <h2 className="font-semibold text-slate-800">Nueva carrera</h2>
          <p className="text-sm text-slate-500 mt-1 mb-5">Cree la carrera para generar el codigo de vinculacion</p>
          <Button onClick={nuevaCarrera} disabled={creando} className="w-full h-12 text-base">
            {creando ? "Creando…" : "Poner nueva carrera"}
          </Button>
          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
        </div>
      )}

      {carrera && (
        <div className="space-y-4">
          <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 text-white rounded-2xl p-6 shadow-lg text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-white/80">Codigo de la carrera</p>
            <p className="text-6xl font-extrabold tracking-[0.2em] tabular-nums mt-2">{carrera.Codigo}</p>
            <p className="text-sm text-white/80 mt-2">Compartalo con los evaluadores auxiliares</p>
          </div>

          <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-lg text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-white/60">Cronometro</p>
            <div className="my-3">
              <TimerDisplay segundos={segundos} size="lg" className={activo ? "text-white" : "text-white/40"} />
            </div>
            {carrera.Estado === "espera" && (
              <Button
                onClick={iniciarCronometro}
                className="w-full h-14 text-lg font-bold bg-emerald-500 hover:bg-emerald-400 text-white"
              >
                INICIAR CRONOMETRO
              </Button>
            )}
            {carrera.Estado === "en_curso" && (
              <p className="text-sm font-semibold text-emerald-400">Cronometro en marcha</p>
            )}
            {carrera.Estado === "finalizada" && (
              <p className="text-sm font-semibold text-white/70">Carrera finalizada</p>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Proyeccion en vivo</p>
            <p className="text-sm text-slate-600 break-all mt-1">{liveUrl}</p>
            <div className="flex gap-2 mt-3">
              <Button variant="secondary" className="flex-1" onClick={copiarEnlace}>
                {copiado ? "Copiado" : "Copiar enlace"}
              </Button>
              <Button className="flex-1" onClick={() => window.open(liveUrl, "_blank")}>
                Abrir en vivo
              </Button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-800">Participantes</h3>
              <span className="text-xs font-semibold text-slate-500">{finalizados}/{participantes.length} en meta</span>
            </div>
            <ListaCorredores
              items={participantes}
              mostrarEvaluador
              emptyMsg="Los participantes apareceran aqui cuando los auxiliares los ingresen."
            />
          </div>

          {msg && <p className="text-sm text-red-600">{msg}</p>}

          <div className="flex gap-2">
            {carrera.Estado === "en_curso" && (
              <Button variant="secondary" className="flex-1" onClick={finalizarCarrera}>
                Finalizar carrera
              </Button>
            )}
            <Button variant="outline" className="flex-1" onClick={cerrarSesion}>
              Cerrar
            </Button>
          </div>
        </div>
      )}
    </AppShell>
  );
}
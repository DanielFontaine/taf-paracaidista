import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import PostulanteForm from "@/components/PostulanteForm";
import ProgressBadge from "@/components/ProgressBadge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { buildProgresoMap, buildEstacionesMap, formatDocumento, sanitizeDocumento, DISCIPLINAS, ESTACIONES } from "@/lib/postulantes-utils";
import { calcularTAF, formatTiempo } from "@/lib/taf-puntaje";
import ResumenEvento from "@/components/ResumenEvento";
import { CODIGO_RESUMEN } from "@/lib/resumen-evento";

const PDF_TABLAS = "https://media.base44.com/files/public/6a720efa4edfec96e6684a30/83ce088d1_TablasdelTAFParacaidistaacordeMOF16-44.pdf";

// Participante: ingresa su cedula y ve sus resultados (solo lectura).
export default function ParticipanteConsulta() {
  const navigate = useNavigate();
  const [postulante, setPostulante] = useState(null);
  const [progreso, setProgreso] = useState(null);
  const [estaciones, setEstaciones] = useState(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [cedula, setCedula] = useState("");
  const [noEncontrado, setNoEncontrado] = useState(false);
  const [modoRegistro, setModoRegistro] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [resumen, setResumen] = useState(false);

  // Unica forma de consultar: la cedula completa del postulante.
  const buscarPorCedula = async (doc) => {
    setLoading(true);
    setMsg("");
    setNoEncontrado(false);
    setPostulante(null);
    setProgreso(null);
    setEstaciones(null);
    setModoRegistro(false);
    setResumen(false);
    try {
      const matches = await base44.entities.Postulante.filter({ Documento: doc });
      if (!matches || matches.length === 0) {
        setNoEncontrado(true);
        return;
      }
      const p = matches[0];
      const [evals, asis] = await Promise.all([
        base44.entities.Evaluacion.filter({ ID_NFC: p.ID_NFC }),
        base44.entities.AsistenciaEstacion.filter({ ID_NFC: p.ID_NFC }),
      ]);
      setPostulante(p);
      setProgreso(buildProgresoMap(evals)[p.ID_NFC] || { count: 0, byDisciplina: {}, evals: [] });
      setEstaciones(buildEstacionesMap(asis)[p.ID_NFC] || { count: 0, byEstacion: {} });
    } catch (e) {
      setMsg("Error al consultar los datos.");
    } finally {
      setLoading(false);
    }
  };

  const consultar = (e) => {
    e.preventDefault();
    const doc = sanitizeDocumento(cedula);
    if (!doc) return;
    // Cedula de resumen: muestra el desarrollo del evento en vivo
    if (doc === CODIGO_RESUMEN) {
      setMsg("");
      setNoEncontrado(false);
      setModoRegistro(false);
      setPostulante(null);
      setResumen(true);
      return;
    }
    buscarPorCedula(doc);
  };

  const registrar = async (data) => {
    setSubmitting(true);
    setMsg("");
    try {
      const existe = await base44.entities.Postulante.filter({ ID_NFC: data.ID_NFC });
      if (existe && existe.length > 0) {
        setMsg("Ya existe un postulante con ese codigo QR.");
        return;
      }
      await base44.entities.Postulante.create(data);
      const doc = sanitizeDocumento(data.Documento);
      setCedula(doc);
      await buscarPorCedula(doc);
    } catch (e) {
      setMsg("No se pudo registrar el postulante.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppShell title="Consulta de Resultados" subtitle="Participante" onBack={() => navigate("/")} accent="blue">
      {!postulante && !modoRegistro && !resumen && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="text-center mb-5">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 mb-3">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12a7 7 0 0114 0"/><path d="M8.5 12a3.5 3.5 0 017 0"/><circle cx="12" cy="12" r="1"/></svg>
            </div>
            <h2 className="font-semibold text-slate-800">Ingrese su cedula</h2>
            <p className="text-sm text-slate-500 mt-1">Necesita su cedula completa para ver su progreso</p>
          </div>
          <form onSubmit={consultar} className="flex gap-2">
            <Input
              value={cedula}
              onChange={(e) => setCedula(sanitizeDocumento(e.target.value))}
              placeholder="Cedula"
              inputMode="numeric"
              autoFocus
            />
            <Button type="submit" disabled={loading || !cedula.trim()}>
              {loading ? "Consultando…" : "Consultar"}
            </Button>
          </form>
          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
          {noEncontrado && (
            <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
              <p className="text-sm text-amber-800">No se encontro un postulante con esa cedula.</p>
              <button
                type="button"
                onClick={() => setModoRegistro(true)}
                className="mt-2 text-sm font-semibold text-blue-600"
              >
                Registrarme
              </button>
            </div>
          )}
        </div>
      )}

      {modoRegistro && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="text-center mb-5">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-50 mb-3">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
            </div>
            <h2 className="font-semibold text-slate-800">Registrar postulante</h2>
            <p className="text-sm text-slate-500 mt-1">Cedula: <span className="font-mono font-semibold">{formatDocumento(cedula)}</span></p>
          </div>
          <PostulanteForm onSubmit={registrar} submitting={submitting} initial={{ Documento: sanitizeDocumento(cedula) }} />
          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
          <button
            onClick={() => { setModoRegistro(false); setMsg(""); }}
            className="w-full text-sm text-slate-500 font-medium py-3"
          >
            Cancelar
          </button>
        </div>
      )}

      {postulante && progreso && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Postulante</p>
                <h2 className="text-xl font-bold text-slate-900 mt-0.5">{postulante.Nombre_Completo}</h2>
                <p className="text-sm text-slate-500 mt-1">Doc: {formatDocumento(postulante.Documento)}</p>
              </div>
              <ProgressBadge count={progreso.count} size="lg" />
            </div>
          </div>

          <div className="grid gap-3">
            {DISCIPLINAS.map((d) => {
              const ev = progreso.byDisciplina?.[d];
              const isCarrera = d === "Carrera";
              return (
                <div key={d} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">{d}</p>
                    <p className="text-lg font-bold text-slate-900 mt-0.5">
                      {ev ? (isCarrera ? formatTiempo(ev.Resultado) : `${ev.Resultado} rep`) : "—"}
                    </p>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${ev ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"}`}>
                    {ev ? "Registrado" : "Pendiente"}
                  </span>
                </div>
              );
            })}
          </div>

          {postulante.Edad == null && (
            <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl px-4 py-3 text-sm text-center">
              Consulte en mesa de entradas para registrar su edad y obtener el puntaje.
            </div>
          )}

          {postulante.Edad != null && (() => {
            const taf = calcularTAF(progreso.evals || [], postulante.Edad);
            if (taf.total === null) return null;
            const aprobado = taf.situacion === "APROBADO";
            return (
              <>
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center">
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Puntaje Total Obtenido</p>
                  <p className="text-4xl font-extrabold text-slate-900 mt-1 tabular-nums">
                    {taf.total} <span className="text-lg font-medium text-slate-500">puntos</span>
                  </p>
                  <div className={`mt-4 inline-flex flex-col items-center rounded-xl border-2 px-10 py-3 ${aprobado ? "border-emerald-500 bg-emerald-50" : "border-red-500 bg-red-50"}`}>
                    <span className={`text-2xl font-extrabold tracking-wide ${aprobado ? "text-emerald-600" : "text-red-600"}`}>
                      {taf.situacion}
                    </span>
                    {taf.concepto && (
                      <span className={`text-sm font-bold uppercase tracking-widest mt-0.5 ${aprobado ? "text-emerald-700" : "text-red-700"}`}>
                        {taf.concepto}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-4 leading-relaxed font-medium">
                    INDISTINTAMENTE DE SU CONDICIÓN DIRIJASE AL AREA DE ENTRENAMIENTO PARACAIDISTA PARA PARTICIPAR DE LA REINSTRUCCIÓN TECNICA
                  </p>
                </div>

                <a
                  href={PDF_TABLAS}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 bg-slate-800 text-white rounded-xl py-3 text-sm font-semibold hover:bg-slate-900 transition"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/></svg>
                  TABLAS DE PUNTAJE
                </a>
              </>
            );
          })()}

          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
            <h3 className="font-semibold text-slate-800 mb-1">Reinstruccion Paracaidista</h3>
            <p className="text-xs text-slate-500 mb-3">Progreso por estacion</p>
            <div className="space-y-2">
              {ESTACIONES.map((est) => {
                const done = !!estaciones?.byEstacion?.[est];
                return (
                  <div key={est} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 ${done ? "bg-emerald-50 border border-emerald-200" : "bg-red-50 border border-red-200"}`}>
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${done ? "bg-emerald-500 text-white" : "bg-red-500 text-white"}`}>
                      {done ? (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                      ) : (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M12 9v4M12 17h.01"/></svg>
                      )}
                    </div>
                    <span className={`text-sm font-medium flex-1 ${done ? "text-emerald-800" : "text-red-800"}`}>{est}</span>
                    <span className={`text-xs font-semibold ${done ? "text-emerald-600" : "text-red-600"}`}>{done ? "Completada" : "Pendiente"}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => { setPostulante(null); setProgreso(null); setEstaciones(null); setCedula(""); setNoEncontrado(false); }}
            className="w-full text-sm text-blue-600 font-medium py-3"
          >
            Consultar otra cedula
          </button>
        </div>
      )}

      {resumen && (
        <ResumenEvento
          onCerrar={() => {
            setResumen(false);
            setCedula("");
          }}
        />
      )}
    </AppShell>
  );
}
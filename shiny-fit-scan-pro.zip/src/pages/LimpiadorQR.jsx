import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import QrScanner from "@/components/QrScanner";
import { base44 } from "@/api/base44Client";

// Limpiador de QR: al escanear un brazalete se elimina el postulante registrado
// en ese codigo y queda libre para asignarselo a un nuevo participante.
export default function LimpiadorQR() {
  const navigate = useNavigate();
  const [liberado, setLiberado] = useState(null);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handleScan = async (idNfc) => {
    setLoading(true);
    setMsg("");
    setLiberado(null);
    try {
      const matches = await base44.entities.Postulante.filter({ ID_NFC: idNfc });
      if (!matches || matches.length === 0) {
        setMsg(`El codigo ${idNfc} no tiene ningun postulante registrado.`);
        return;
      }
      const nombre = matches[0].Nombre_Completo;
      await base44.entities.Postulante.deleteMany({ ID_NFC: idNfc });
      setLiberado({ idNfc, nombre });
    } catch (e) {
      setMsg("No se pudo liberar el codigo QR.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppShell title="Limpiador de QR" subtitle="Liberar brazalete" onBack={() => navigate("/")} accent="rose">
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <h2 className="font-semibold text-slate-800 mb-1">Escanear brazalete</h2>
        <p className="text-sm text-slate-500 mb-4">Al escanear, el postulante registrado se elimina y el codigo queda libre.</p>
        <QrScanner onScan={handleScan} label="Escanear codigo QR" />
        {loading && <p className="text-sm text-rose-600 mt-3 animate-pulse">Liberando…</p>}
        {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
      </div>

      {liberado && (
        <div className="mt-4 bg-emerald-50 border-2 border-emerald-500 rounded-2xl p-6 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-500 text-white mb-3">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
          </div>
          <p className="text-2xl font-extrabold text-emerald-700 tracking-tight">QR liberado</p>
          <div className="mt-4 rounded-xl bg-white border border-emerald-200 px-4 py-3 text-left">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Codigo liberado</p>
            <p className="font-mono font-bold text-slate-800 mt-0.5">{liberado.idNfc}</p>
            <p className="text-sm text-slate-500 mt-1">Postulante eliminado: {liberado.nombre}</p>
          </div>
        </div>
      )}
    </AppShell>
  );
}
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import PostulanteList from "@/components/PostulanteList";
import ModalDetalleTAF from "@/components/ModalDetalleTAF";
import ModalDetalleEstaciones from "@/components/ModalDetalleEstaciones";
import EstacionesDots from "@/components/EstacionesDots";
import { base44 } from "@/api/base44Client";
import {
  buildProgresoMap,
  buildEstacionesMap,
  formatDocumento,
  sanitizeDocumento,
  ESTACION_LIBRE_MILITAR,
  esLibreMilitarForm,
} from "@/lib/postulantes-utils";
import LibreMilitarBadge from "@/components/LibreMilitarBadge";
import EditarInformacion from "@/components/EditarInformacion";
import TarjetasNfc from "@/components/TarjetasNfc";
import CedulaAutocomplete from "@/components/CedulaAutocomplete";
import BotonExportarResultados from "@/components/BotonExportarResultados";

const SECCIONES = [
  { key: "listado", label: "Listado de Participantes" },
  { key: "evaluacion", label: "Evaluacion Fisica" },
  { key: "reinstruccion", label: "Reinstruccion Tecnica" },
  { key: "editar", label: "Editar Informacion" },
  { key: "tarjetas", label: "Codigos QR" },
];

const VIEWS_EVAL = [
  { key: "total", label: "Total", icon: "M3 6h18M3 12h18M3 18h18" },
  { key: "sin", label: "Sin evaluar", icon: "M12 9v4M12 17h.01" },
  { key: "proceso", label: "En proceso", icon: "M12 8v4l3 3" },
  { key: "evaluados", label: "Evaluados", icon: "M20 6L9 17l-5-5" },
];

function BadgeApto({ estado }) {
  if (estado === "VALIDADO") {
    return <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">Apto: Validado</span>;
  }
  if (estado === "NO_VALIDADO") {
    return <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700">Apto: No Validado</span>;
  }
  return <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">Apto: Pendiente</span>;
}

export default function CentroComputos() {
  const navigate = useNavigate();
  const [seccion, setSeccion] = useState("listado");
  const [postulantes, setPostulantes] = useState([]);
  const [evaluaciones, setEvaluaciones] = useState([]);
  const [asistencias, setAsistencias] = useState([]);
  const [aptos, setAptos] = useState([]);
  const [listadoForm, setListadoForm] = useState([]);
  const [busquedaDoc, setBusquedaDoc] = useState("");
  const [fGrado, setFGrado] = useState("");
  const [fUnidad, setFUnidad] = useState("");
  const [fTarjeta, setFTarjeta] = useState("");
  const [fApto, setFApto] = useState("");
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");
  const [detalleTAF, setDetalleTAF] = useState(null);
  const [detalleEstaciones, setDetalleEstaciones] = useState(null);
  const [viewEval, setViewEval] = useState("total");

  const cargar = useCallback(async () => {
    setLoading(true);
    try {
      const [posts, evals, asis, am] = await Promise.all([
        base44.entities.Postulante.list("-created_date"),
        base44.entities.Evaluacion.list("-created_date", 500),
        base44.entities.AsistenciaEstacion.list("-created_date", 500),
        base44.entities.AptoMedico.list("-created_date", 500),
      ]);
      setPostulantes(posts || []);
      setEvaluaciones(evals || []);
      setAsistencias(asis || []);
      setAptos(am || []);
      // listado desde la planilla de Google Form
      try {
        const res = await base44.functions.invoke("listarPostulantesForm", {});
        setListadoForm(res.data?.postulantes || []);
      } catch (e) {
        setListadoForm([]);
      }
    } catch (e) {
      setMsg("Error al cargar los datos.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { cargar(); }, [cargar]);

  const progresoMap = buildProgresoMap(evaluaciones);
  const estacionesMap = buildEstacionesMap(asistencias);

  // Mapa documento -> ID_NFC (postulantes con codigo QR asignado)
  const nfcByDoc = {};
  (postulantes || []).forEach((p) => {
    const doc = String(p.Documento || "").replace(/\D/g, "");
    if (doc) nfcByDoc[doc] = p.ID_NFC;
  });
  // Mapa documento -> estado apto medico
  const aptoByDoc = {};
  (aptos || []).forEach((a) => {
    const doc = String(a.Documento || "").replace(/\D/g, "");
    if (doc) aptoByDoc[doc] = a.Estado;
  });

  // Quienes declararon la Modalidad Salto Caida Libre en el formulario de ingreso
  const docsLibreMilitar = new Set(
    listadoForm.filter((f) => esLibreMilitarForm(f.tipoReinstruccion)).map((f) => sanitizeDocumento(f.documento))
  );
  // QR que ya pasaron por la reinstruccion de caida libre militar
  const libreMilitarOk = new Set(
    (asistencias || []).filter((a) => a.Estacion === ESTACION_LIBRE_MILITAR).map((a) => a.ID_NFC)
  );

  // Opciones unicas para filtros
  const gradosUnicos = Array.from(new Set(listadoForm.map((p) => p.grado).filter(Boolean))).sort();
  const unidadesUnicas = Array.from(new Set(listadoForm.map((p) => p.unidad).filter(Boolean))).sort();

  const listadoFiltrado = listadoForm.filter((p) => {
    const doc = String(p.documento || "").replace(/\D/g, "");
    if (busquedaDoc.trim() && !doc.includes(busquedaDoc.trim().replace(/\D/g, ""))) return false;
    if (fGrado && p.grado !== fGrado) return false;
    if (fUnidad && p.unidad !== fUnidad) return false;
    const tieneNfc = !!nfcByDoc[doc];
    if (fTarjeta === "si" && !tieneNfc) return false;
    if (fTarjeta === "no" && tieneNfc) return false;
    const apto = aptoByDoc[doc];
    if (fApto === "pendiente" && apto) return false;
    if (fApto === "validado" && apto !== "VALIDADO") return false;
    if (fApto === "no_validado" && apto !== "NO_VALIDADO") return false;
    return true;
  });

  const filtrar = (key) => {
    if (key === "sin") return postulantes.filter((p) => (progresoMap[p.ID_NFC]?.count || 0) === 0);
    if (key === "proceso") return postulantes.filter((p) => {
      const c = progresoMap[p.ID_NFC]?.count || 0;
      return c > 0 && c < 3;
    });
    if (key === "evaluados") return postulantes.filter((p) => (progresoMap[p.ID_NFC]?.count || 0) >= 3);
    return postulantes;
  };

  const verDetalleTAF = (p) => {
    const prog = progresoMap[p.ID_NFC] || { byDisciplina: {} };
    const evs = Object.values(prog.byDisciplina || {});
    setDetalleTAF({ postulante: p, evaluaciones: evs });
  };

  const verDetalleEstaciones = (p) => {
    setDetalleEstaciones({ postulante: p });
  };

  const countsEval = {
    total: postulantes.length,
    sin: filtrar("sin").length,
    proceso: filtrar("proceso").length,
    evaluados: filtrar("evaluados").length,
  };

  return (
    <AppShell title="Centro de Computos" subtitle="Gestion y seguimiento" onBack={() => navigate("/")} accent="emerald">
      {detalleTAF && (
        <ModalDetalleTAF
          postulante={detalleTAF.postulante}
          evaluaciones={detalleTAF.evaluaciones}
          onClose={() => setDetalleTAF(null)}
        />
      )}
      {detalleEstaciones && (
        <ModalDetalleEstaciones
          postulante={detalleEstaciones.postulante}
          estacionesMap={estacionesMap}
          onClose={() => setDetalleEstaciones(null)}
        />
      )}

      <BotonExportarResultados />

      {/* Tabs de seccion */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 mb-4">
        {SECCIONES.map((s) => {
          const active = seccion === s.key;
          return (
            <button
              key={s.key}
              onClick={() => setSeccion(s.key)}
              className={`flex-shrink-0 rounded-full px-4 py-2 text-sm font-medium transition whitespace-nowrap ${
                active ? "bg-emerald-600 text-white shadow" : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300"
              }`}
            >
              {s.label}
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-emerald-600 rounded-full animate-spin"></div>
        </div>
      ) : seccion === "listado" ? (
        <div>
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm mb-4 space-y-3">
            <CedulaAutocomplete
              value={busquedaDoc}
              onChange={setBusquedaDoc}
              postulantes={listadoForm}
              placeholder="Buscar por cedula…"
            />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <select value={fGrado} onChange={(e) => setFGrado(e.target.value)} className="rounded-md border border-input bg-transparent px-2 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
                <option value="">Grado: Todos</option>
                {gradosUnicos.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
              <select value={fUnidad} onChange={(e) => setFUnidad(e.target.value)} className="rounded-md border border-input bg-transparent px-2 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
                <option value="">Unidad: Todas</option>
                {unidadesUnicas.map((u) => <option key={u} value={u}>{u}</option>)}
              </select>
              <select value={fTarjeta} onChange={(e) => setFTarjeta(e.target.value)} className="rounded-md border border-input bg-transparent px-2 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
                <option value="">Codigo QR: Todos</option>
                <option value="si">Codigo QR asignado</option>
                <option value="no">Codigo QR no asignado</option>
              </select>
              <select value={fApto} onChange={(e) => setFApto(e.target.value)} className="rounded-md border border-input bg-transparent px-2 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
                <option value="">Apto: Todos</option>
                <option value="pendiente">Pendiente</option>
                <option value="validado">Validado</option>
                <option value="no_validado">No validado</option>
              </select>
            </div>
            <p className="text-sm text-slate-500">
              Mostrando <span className="font-semibold text-slate-800">{listadoFiltrado.length}</span> de {listadoForm.length} postulantes
            </p>
          </div>
          {listadoForm.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm">{msg || "No hay postulantes en la base de datos."}</p>
            </div>
          ) : listadoFiltrado.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm">No hay postulantes que coincidan con los filtros.</p>
            </div>
          ) : (
            <ul className="space-y-2">
              {listadoFiltrado.map((p, i) => {
                const doc = String(p.documento || "").replace(/\D/g, "");
                const nfc = nfcByDoc[doc];
                const apto = aptoByDoc[doc];
                return (
                  <li key={i} className="bg-white border border-slate-200 rounded-xl px-4 py-3 shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 truncate">
                          {p.grado} {p.nombre} {p.apellido}
                        </p>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1">
                          <span className="text-xs text-slate-500">{formatDocumento(p.documento)}</span>
                          <span className="text-[11px] text-slate-300">·</span>
                          <span className="text-xs text-slate-600 truncate">{p.unidad}</span>
                        </div>
                      </div>
                      <BadgeApto estado={apto} />
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-100">
                      {nfc ? (
                        <p className="text-xs font-mono text-slate-700">
                          Codigo QR: <span className="font-semibold">{nfc}</span>
                        </p>
                      ) : (
                        <p className="text-xs font-semibold text-red-600">Codigo QR no asignado</p>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      ) : seccion === "evaluacion" ? (
        <div>
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 mb-4">
            {VIEWS_EVAL.map((v) => {
              const active = viewEval === v.key;
              return (
                <button
                  key={v.key}
                  onClick={() => setViewEval(v.key)}
                  className={`flex-shrink-0 inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-medium transition whitespace-nowrap ${
                    active ? "bg-emerald-600 text-white shadow" : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d={v.icon}/></svg>
                  {v.label}
                  <span className={`ml-0.5 text-[11px] rounded-full px-1.5 py-0.5 ${active ? "bg-white/20" : "bg-slate-100 text-slate-500"}`}>{countsEval[v.key]}</span>
                </button>
              );
            })}
          </div>
          <PostulanteList
            postulantes={filtrar(viewEval)}
            progresoMap={progresoMap}
            onSelect={verDetalleTAF}
            emptyMessage={
              viewEval === "sin" ? "No hay postulantes sin evaluar." :
              viewEval === "proceso" ? "No hay postulantes en proceso." :
              viewEval === "evaluados" ? "No hay postulantes evaluados." :
              "No hay postulantes registrados."
            }
          />
        </div>
      ) : seccion === "reinstruccion" ? (
        <div>
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm mb-4">
            <p className="text-sm text-slate-500">
              Total registrados: <span className="font-semibold text-slate-800">{postulantes.length}</span>
            </p>
          </div>
          {postulantes.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <svg className="mx-auto mb-3 opacity-50" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>
              <p className="text-sm">No hay postulantes registrados.</p>
            </div>
          ) : (
            <ul className="space-y-2">
              {postulantes.map((p) => {
                const prog = estacionesMap[p.ID_NFC] || { count: 0 };
                const esLibreMilitar = docsLibreMilitar.has(sanitizeDocumento(p.Documento));
                return (
                  <li key={p.id}>
                    <button
                      onClick={() => verDetalleEstaciones(p)}
                      className="w-full text-left bg-white border border-slate-200 rounded-xl px-4 py-3 hover:border-slate-300 hover:shadow-sm transition flex items-center gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 truncate">{p.Nombre_Completo}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-slate-500">{formatDocumento(p.Documento)}</span>
                          <span className="text-[11px] text-slate-400">·</span>
                          <span className="text-xs font-mono text-slate-400 truncate">{p.ID_NFC}</span>
                        </div>
                        {esLibreMilitar && (
                          <div className="mt-2">
                            <LibreMilitarBadge ok={libreMilitarOk.has(p.ID_NFC)} />
                          </div>
                        )}
                      </div>
                      {!esLibreMilitar && <EstacionesDots byEstacion={prog.byEstacion} />}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      ) : seccion === "editar" ? (
        <EditarInformacion
          postulantes={postulantes}
          evaluaciones={evaluaciones}
          aptos={aptos}
          onReload={cargar}
        />
      ) : (
        <TarjetasNfc postulantes={postulantes} />
      )}
    </AppShell>
  );
}
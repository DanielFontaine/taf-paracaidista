import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import CedulaAutocomplete from "@/components/CedulaAutocomplete";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import usePostulantesForm from "@/hooks/usePostulantesForm";

export default function ControlAptoMedico() {
  const navigate = useNavigate();
  const [cedula, setCedula] = useState("");
  const [buscando, setBuscando] = useState(false);
  const [resumen, setResumen] = useState(null);
  const [documento, setDocumento] = useState("");
  const [noEncontrado, setNoEncontrado] = useState(false);
  const [msg, setMsg] = useState("");

  const [estado, setEstado] = useState(""); // "VALIDADO" | "NO_VALIDADO"
  const [observacion, setObservacion] = useState("");
  const [existente, setExistente] = useState(null);
  const [guardando, setGuardando] = useState(false);
  const [ok, setOk] = useState(false);

  // Cedulas de la planilla del formulario para las sugerencias de busqueda.
  const postulantesForm = usePostulantesForm();

  const buscar = async (e) => {
    e.preventDefault();
    if (!cedula.trim()) return;
    setBuscando(true);
    setMsg("");
    setResumen(null);
    setNoEncontrado(false);
    setOk(false);
    setEstado("");
    setObservacion("");
    setExistente(null);
    try {
      const res = await base44.functions.invoke("buscarPostulanteForm", { cedula: cedula.trim() });
      const d = res.data;
      if (d?.encontrada) {
        setResumen(d.resumen || []);
        const doc = String(d.documento || "").replace(/\D/g, "");
        setDocumento(doc);
        // buscar apto medico existente
        if (doc) {
          const prev = await base44.entities.AptoMedico.filter({ Documento: doc });
          if (prev && prev.length > 0) {
            setExistente(prev[0]);
            setEstado(prev[0].Estado);
            setObservacion(prev[0].Observacion || "");
          }
        }
      } else if (d?.error) {
        setMsg(d.error);
      } else {
        setNoEncontrado(true);
      }
    } catch (err) {
      setMsg("Error al buscar en el formulario.");
    } finally {
      setBuscando(false);
    }
  };

  const guardar = async (e) => {
    e.preventDefault();
    setMsg("");
    setOk(false);
    if (!estado) { setMsg("Seleccione VALIDADO o NO VALIDADO."); return; }
    if (estado === "NO_VALIDADO" && !observacion.trim()) {
      setMsg("Debe ingresar una observacion cuando no es validado.");
      return;
    }
    setGuardando(true);
    try {
      if (existente) {
        await base44.entities.AptoMedico.update(existente.id, {
          Estado: estado,
          Observacion: estado === "NO_VALIDADO" ? observacion.trim() : "",
        });
      } else {
        await base44.entities.AptoMedico.create({
          Documento: documento,
          Estado: estado,
          Observacion: estado === "NO_VALIDADO" ? observacion.trim() : "",
        });
      }
      setOk(true);
      const prev = await base44.entities.AptoMedico.filter({ Documento: documento });
      if (prev && prev.length > 0) setExistente(prev[0]);
    } catch (err) {
      setMsg("No se pudo guardar el apto medico.");
    } finally {
      setGuardando(false);
    }
  };

  return (
    <AppShell title="Control Apto Medico" subtitle="Validacion medica por cedula" onBack={() => navigate("/")} accent="emerald">
      <form onSubmit={buscar} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-4">
        <h2 className="font-semibold text-slate-800 mb-1">Buscar postulante</h2>
        <p className="text-sm text-slate-500 mb-4">Ingrese el numero de cedula del postulante</p>
        <div className="flex gap-2">
          <CedulaAutocomplete
            value={cedula}
            onChange={setCedula}
            postulantes={postulantesForm}
            placeholder="Cedula"
            autoFocus
          />
          <Button type="submit" disabled={buscando || !cedula.trim()}>
            {buscando ? "Buscando…" : "Buscar"}
          </Button>
        </div>
        {msg && !resumen && <p className="text-sm text-red-600 mt-3">{msg}</p>}
        {noEncontrado && (
          <p className="text-sm text-amber-700 mt-3 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            No se encontro un postulante con esa cedula en el formulario.
          </p>
        )}
      </form>

      {resumen && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-4">
          <h3 className="font-semibold text-slate-800 mb-1">Datos del formulario</h3>
          <p className="text-xs text-slate-500 mb-3">Verifique que sea la persona correcta:</p>
          <dl className="space-y-2">
            {resumen.map((item, i) => (
              <div key={i} className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2 border-b border-slate-100 pb-2">
                <dt className="text-sm font-medium text-slate-500 sm:w-2/5">{item.label}</dt>
                <dd className="text-sm text-slate-800 font-semibold flex-1 break-words">{item.value || "—"}</dd>
              </div>
            ))}
          </dl>
        </div>
      )}

      {resumen && (
        <form onSubmit={guardar} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="font-semibold text-slate-800 mb-1">Apto Medico</h3>
          <p className="text-sm text-slate-500 mb-4">
            {existente ? "Registro existente — actualice el estado" : "Defina el resultado del control medico"}
          </p>
          {existente && (
            <div className="mb-4 flex items-start gap-2 bg-amber-50 border border-amber-300 rounded-lg px-3 py-2.5">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600 flex-shrink-0 mt-0.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>
              <p className="text-sm text-amber-800">
                Este apto ya fue verificado como <strong>{existente.Estado === "VALIDADO" ? "VALIDADO" : "NO VALIDADO"}</strong>. Al guardar sobrescribira el registro anterior.
              </p>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <button
              type="button"
              onClick={() => setEstado("VALIDADO")}
              className={`rounded-xl border-2 py-4 text-sm font-bold transition ${
                estado === "VALIDADO"
                  ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                  : "border-slate-200 bg-white text-slate-500 hover:border-slate-300"
              }`}
            >
              VALIDADO
            </button>
            <button
              type="button"
              onClick={() => setEstado("NO_VALIDADO")}
              className={`rounded-xl border-2 py-4 text-sm font-bold transition ${
                estado === "NO_VALIDADO"
                  ? "border-red-500 bg-red-50 text-red-700"
                  : "border-slate-200 bg-white text-slate-500 hover:border-slate-300"
              }`}
            >
              NO VALIDADO
            </button>
          </div>

          {estado === "NO_VALIDADO" && (
            <div className="mb-4">
              <label className="text-xs font-medium text-slate-500">Observacion</label>
              <textarea
                value={observacion}
                onChange={(e) => setObservacion(e.target.value)}
                placeholder="Motivo por el cual no es validado"
                rows={3}
                className="mt-1 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>
          )}

          {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
          {ok && (
            <p className="text-sm text-emerald-700 mt-3 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
              Apto medico guardado correctamente.
            </p>
          )}
          <Button type="submit" className="w-full mt-2" disabled={guardando || !estado}>
            {guardando ? "Guardando…" : "Guardar apto medico"}
          </Button>
        </form>
      )}
    </AppShell>
  );
}
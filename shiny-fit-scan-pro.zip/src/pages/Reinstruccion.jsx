import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import QrScanner from "@/components/QrScanner";
import { base44 } from "@/api/base44Client";
import {
  ESTACIONES,
  ESTACION_LIBRE_MILITAR,
  esLibreMilitarForm,
  sanitizeDocumento,
  formatDocumento,
  PIN_REINSTRUCCION,
} from "@/lib/postulantes-utils";

const ESTACION_ICON = {
  "Torre 34 Pies": "M12 2v20M8 6h8M6 10h12M4 14h16",
  "Cancha de Caidas": "M4 20h4v-4h4v-4h4v-4h4",
  "Avion Simulado": "M21 16v-2l-8-5V3.5a1.5 1.5 0 00-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z",
  "Navegacion": "M3 11l19-9-9 19-2-8-8-2z",
  "Equipamiento": "M2 11a10 10 0 0120 0M2 11l10 9M22 11l-10 9M12 11v9M7 11l5 9M17 11l-5 9",
  [ESTACION_LIBRE_MILITAR]: "M4 10a8 8 0 0116 0M12 10v9M8 19h8",
};

export default function Reinstruccion() {
  const navigate = useNavigate();
  const [estacion, setEstacion] = useState(null);
  const [postulantes, setPostulantes] = useState([]);
  const [asistencias, setAsistencias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [msg, setMsg] = useState("");
  const [lastMarked, setLastMarked] = useState(null);
  const [idNfcScan, setIdNfcScan] = useState("");
  // Documentos que en el formulario marcaron la Modalidad Salto Caida Libre
  const [docsLibreMilitar, setDocsLibreMilitar] = useState(new Set());

  const cargar = useCallback(async () => {
    try {
      const [posts, asis, form] = await Promise.all([
        base44.entities.Postulante.list("-created_date"),
        base44.entities.AsistenciaEstacion.list("-created_date", 500),
        base44.functions
          .invoke("listarPostulantesForm", {})
          .then((res) => res.data?.postulantes || [])
          .catch(() => []),
      ]);
      setPostulantes(posts || []);
      setAsistencias(asis || []);
      setDocsLibreMilitar(
        new Set(
          form.filter((f) => esLibreMilitarForm(f.tipoReinstruccion)).map((f) => sanitizeDocumento(f.documento))
        )
      );
    } catch (e) {
      setMsg("Error al cargar datos.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { cargar(); }, [cargar]);

  // Mapa ID_NFC -> postulante. La lista viene ordenada por created_date descendente
  // (mas reciente primero), por lo que nos quedamos con el primer match: si un QR
  // fue grabado con un nombre, borrado y vuelto a grabar con otro, prevalece el actual.
  const postulanteByNfc = {};
  postulantes.forEach((p) => { if (!postulanteByNfc[p.ID_NFC]) postulanteByNfc[p.ID_NFC] = p; });

  const markedForStation = estacion ? asistencias.filter((a) => a.Estacion === estacion) : [];
  const markedNfcSet = new Set(markedForStation.map((a) => a.ID_NFC));

  const handleScan = async (idNfc) => {
    if (!estacion) return;
    setScanning(true);
    setMsg("");
    setLastMarked(null);
    setIdNfcScan(idNfc);
    try {
      const postulante = postulanteByNfc[idNfc];
      if (!postulante) {
        setMsg("QR_NO_ASIGNADO");
        return;
      }
      // La reinstruccion de caida libre militar es solo para quienes la declararon en el formulario
      if (
        estacion === ESTACION_LIBRE_MILITAR &&
        !docsLibreMilitar.has(sanitizeDocumento(postulante.Documento))
      ) {
        setMsg("MODALIDAD");
        return;
      }
      if (markedNfcSet.has(idNfc)) {
        setMsg(postulante.Nombre_Completo + " ya fue marcado en esta estacion.");
        return;
      }
      await base44.entities.AsistenciaEstacion.create({
        ID_NFC: idNfc,
        Nombre: postulante.Nombre_Completo,
        Estacion: estacion,
        Fecha_Hora: new Date().toISOString(),
        PIN_Instructor: PIN_REINSTRUCCION,
      });
      setLastMarked(postulante);
      setMsg("");
      await cargar();
    } catch (e) {
      setMsg("No se pudo registrar la asistencia.");
    } finally {
      setScanning(false);
    }
  };

  if (loading) {
    return (
      <AppShell title="Reinstruccion Tecnica" subtitle="Seleccion de estacion" onBack={() => navigate("/")} accent="violet">
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-violet-600 rounded-full animate-spin"></div>
        </div>
      </AppShell>
    );
  }

  // Vista 1: seleccion de estacion
  if (!estacion) {
    return (
      <AppShell title="Reinstruccion Tecnica" subtitle="Seleccione la estacion a cargo" onBack={() => navigate("/")} accent="violet">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {ESTACIONES.map((est) => {
            const count = asistencias.filter((a) => a.Estacion === est).length;
            return (
              <button
                key={est}
                onClick={() => { setEstacion(est); setMsg(""); setLastMarked(null); }}
                className="group bg-white border border-slate-200 rounded-2xl p-5 text-left hover:border-violet-400 hover:shadow-md transition flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-200 text-black flex items-center justify-center group-hover:bg-slate-300 transition">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={ESTACION_ICON[est]}/></svg>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-800">{est}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{count} registrados</p>
                </div>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 group-hover:text-violet-600 transition"><path d="M9 18l6-6-6-6"/></svg>
              </button>
            );
          })}
        </div>

        <div className="mt-6">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
            Reinstruccion de Caida Libre Militar
          </h3>
          <button
            onClick={() => { setEstacion(ESTACION_LIBRE_MILITAR); setMsg(""); setLastMarked(null); }}
            className="group w-full bg-white border border-amber-200 rounded-2xl p-5 text-left hover:border-amber-400 hover:shadow-md transition flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center group-hover:bg-amber-200 transition">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={ESTACION_ICON[ESTACION_LIBRE_MILITAR]}/></svg>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-slate-800">{ESTACION_LIBRE_MILITAR}</p>
              <p className="text-xs text-slate-500 mt-0.5">
                {asistencias.filter((a) => a.Estacion === ESTACION_LIBRE_MILITAR).length} registrados · solo Modalidad Salto Caida Libre
              </p>
            </div>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 group-hover:text-amber-600 transition"><path d="M9 18l6-6-6-6"/></svg>
          </button>
        </div>
      </AppShell>
    );
  }

  // Vista 2: marca de asistencia para la estacion seleccionada
  return (
    <AppShell title={estacion} subtitle="Marcar asistencia por QR" onBack={() => setEstacion(null)} accent="violet">
      {lastMarked && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-4 mb-4 flex items-center gap-3">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
          <div>
            <p className="text-sm font-semibold">Asistencia registrada</p>
            <p className="text-xs text-emerald-700">{lastMarked.Nombre_Completo}</p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-4">
        <div className="flex items-center justify-between mb-1">
          <h2 className="font-semibold text-slate-800">Escanear codigo QR</h2>
          <span className="text-xs font-medium text-violet-700 bg-violet-100 px-2.5 py-1 rounded-full">{estacion}</span>
        </div>
        <p className="text-sm text-slate-500 mb-4">Escanee el codigo QR del postulante</p>
        <QrScanner onScan={handleScan} label="Escanear QR del postulante" />
        {scanning && <p className="text-sm text-violet-600 mt-3 animate-pulse">Procesando…</p>}
        {msg === "QR_NO_ASIGNADO" && (
          <div className="mt-3 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
            <svg className="mt-0.5 flex-shrink-0" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
            <div>
              <p className="text-sm font-semibold text-red-700">Codigo QR no asignado</p>
              <p className="text-xs text-red-600 mt-0.5">El codigo <span className="font-mono">{idNfcScan || ""}</span> no pertenece a ningun postulante. Verifique que el codigo QR este registrado en el sistema.</p>
            </div>
          </div>
        )}
        {msg === "MODALIDAD" && (
          <div className="mt-3 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
            <svg className="mt-0.5 flex-shrink-0" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
            <div>
              <p className="text-sm font-semibold text-amber-800">Modalidad no habilitada</p>
              <p className="text-xs text-amber-700 mt-0.5">El codigo <span className="font-mono">{idNfcScan || ""}</span> no esta anotado en la Modalidad Salto Caida Libre Militar.</p>
            </div>
          </div>
        )}
        {msg && msg !== "QR_NO_ASIGNADO" && msg !== "MODALIDAD" && <p className="text-sm text-red-600 mt-3">{msg}</p>}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h3 className="font-semibold text-slate-800 mb-1">Postulantes marcados</h3>
        <p className="text-xs text-slate-500 mb-3">{markedForStation.length} en esta estacion</p>
        {markedForStation.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">Aun no hay postulantes marcados.</p>
        ) : (
          <ul className="space-y-2">
            {markedForStation.map((a) => {
              const p = postulanteByNfc[a.ID_NFC];
              // El nombre se guarda al momento de marcar la asistencia, asi se preserva
              // aunque el QR se reasigne despues a otra persona.
              const nombre = a.Nombre || p?.Nombre_Completo || "Desconocido";
              const doc = p ? formatDocumento(p.Documento) : a.ID_NFC;
              return (
                <li key={a.id} className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50 px-3 py-2.5">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">{nombre}</p>
                    <p className="text-xs text-slate-500">{doc}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </AppShell>
  );
}
import React from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { DISCIPLINAS } from "@/lib/postulantes-utils";

// Submenu del evaluador: 3 disciplinas.
export default function EvaluadorMenu() {
  const navigate = useNavigate();
  const config = {
    Barras: { desc: "Repeticiones realizadas", accent: "from-slate-700 to-slate-900", icon: <path d="M3 12h18M6 12V6M18 12V6M6 18v-3M18 18v-3"/> },
    Abdominales: { desc: "Repeticiones realizadas", accent: "from-amber-500 to-amber-700", icon: <path d="M4 12h16M6 12v4M18 12v4"/> },
    Carrera: { desc: "Tiempo en segundos", accent: "from-emerald-600 to-emerald-800", icon: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></> },
  };

  return (
    <AppShell title="Evaluador de TAF" subtitle="Seleccione la estacion" onBack={() => navigate("/")} accent="amber">
      <div className="space-y-3">
        {DISCIPLINAS.map((d) => {
          const c = config[d];
          return (
            <button
              key={d}
              onClick={() => navigate(d === "Carrera" ? "/evaluador/carrera" : `/evaluador/cargar/${d.toLowerCase()}`)}
              className={`group w-full text-left rounded-2xl p-5 text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-gradient-to-br ${c.accent}`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{c.icon}</svg>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold tracking-tight">{d.toUpperCase()}</h3>
                  <p className="text-sm text-white/80">{c.desc}</p>
                </div>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:translate-x-1 transition"><path d="M9 18l6-6-6-6"/></svg>
              </div>
            </button>
          );
        })}
      </div>
    </AppShell>
  );
}
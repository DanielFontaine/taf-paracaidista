import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

// Reloj sincronizado con el servidor: todos los dispositivos miden el mismo
// tiempo aunque tengan la hora local desfasada.
let offset = 0;
let syncPromise = null;

export function serverNow() {
  return Date.now() + offset;
}

export function syncServerClock() {
  if (!syncPromise) {
    syncPromise = base44.functions
      .invoke("serverTime", {})
      .then((res) => {
        const iso = res?.data?.now;
        if (iso) offset = Date.parse(iso) - Date.now();
      })
      .catch(() => {
        // se usa el reloj local
      });
  }
  return syncPromise;
}

// Devuelve los segundos transcurridos desde "inicio" (mientras este activo).
export function useCronometro(inicio, activo) {
  const [segundos, setSegundos] = useState(0);

  useEffect(() => {
    if (!inicio) {
      setSegundos(0);
      return;
    }
    const start = Date.parse(inicio);
    const tick = () => setSegundos(Math.max(0, (serverNow() - start) / 1000));
    tick();
    if (!activo) return;
    const id = setInterval(tick, 100);
    return () => clearInterval(id);
  }, [inicio, activo]);

  return segundos;
}
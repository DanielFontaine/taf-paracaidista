import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

// Carga (una sola vez) el listado de postulantes de la planilla del formulario.
// Se usa para sugerir cedulas mientras el usuario escribe.
export default function usePostulantesForm() {
  const [postulantes, setPostulantes] = useState([]);

  useEffect(() => {
    let activo = true;
    base44.functions
      .invoke("listarPostulantesForm", {})
      .then((res) => {
        if (activo) setPostulantes(res.data?.postulantes || []);
      })
      .catch(() => {
        if (activo) setPostulantes([]);
      });
    return () => {
      activo = false;
    };
  }, []);

  return postulantes;
}
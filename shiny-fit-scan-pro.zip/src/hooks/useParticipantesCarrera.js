import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

// Lista de participantes de una carrera con actualizacion en vivo.
// Si se pasa evaluadorId, solo devuelve los participantes de ese auxiliar.
export function useParticipantesCarrera(carreraId, evaluadorId) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (!carreraId) {
      setItems([]);
      return;
    }

    let activo = true;
    const query = { Carrera_Id: carreraId };
    if (evaluadorId) query.Evaluador_Id = evaluadorId;

    base44.entities.CarreraParticipante
      .filter(query, { sort: "-created_date", limit: 500 })
      .then((res) => {
        if (activo) setItems(res?.items || []);
      })
      .catch(() => {
        if (activo) setItems([]);
      });

    const unsubscribe = base44.entities.CarreraParticipante.subscribe((event) => {
      const rec = event?.data;
      if (!rec || rec.Carrera_Id !== carreraId) return;
      if (evaluadorId && rec.Evaluador_Id !== evaluadorId) return;
      setItems((prev) => {
        if (event.type === "create") {
          if (prev.some((x) => x.id === rec.id)) return prev;
          return [rec, ...prev];
        }
        if (event.type === "update") return prev.map((x) => (x.id === rec.id ? rec : x));
        if (event.type === "delete") return prev.filter((x) => x.id !== rec.id);
        return prev;
      });
    });

    return () => {
      activo = false;
      if (typeof unsubscribe === "function") unsubscribe();
    };
  }, [carreraId, evaluadorId]);

  return items;
}
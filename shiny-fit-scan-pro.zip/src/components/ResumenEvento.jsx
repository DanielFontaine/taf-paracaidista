import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ESTACIONES } from "@/lib/postulantes-utils";
import { calcularResumen, FUERZAS, COLORES_TAF, COLORES_SALTO, MODALIDADES } from "@/lib/resumen-evento";
import GraficaCircular from "@/components/GraficaCircular";

// Resumen en vivo del desarrollo de la reinstruccion tecnica (acceso por cedula 11111111).
export default function ResumenEvento({ onCerrar }) {
  const [datos, setDatos] = useState(null);

  useEffect(() => {
    let activo = true;

    const cargar = async () => {
      const [postulantes, evaluaciones, asistencias, form] = await Promise.all([
        base44.entities.Postulante.filter({}, { fields: ["ID_NFC", "Documento", "Edad"], limit: 1000 }),
        base44.entities.Evaluacion.filter(
          {},
          { fields: ["ID_NFC", "Disciplina", "Resultado", "Distancia", "Ejercicio"], limit: 1000 }
        ),
        base44.entities.AsistenciaEstacion.filter({}, { fields: ["ID_NFC", "Estacion"], limit: 1000 }),
        base44.functions
          .invoke("listarPostulantesForm", {})
          .then((res) => res.data?.postulantes || [])
          .catch(() => []),
      ]);
      if (!activo) return;
      setDatos(
        calcularResumen(
          postulantes.items || [],
          evaluaciones.items || [],
          // La caida libre militar es una reinstruccion aparte: no cuenta como estacion
          (asistencias.items || []).filter((a) => ESTACIONES.includes(a.Estacion)),
          form
        )
      );
    };

    cargar();
    const bajas = ["Postulante", "Evaluacion", "AsistenciaEstacion"].map((nombre) =>
      base44.entities[nombre].subscribe(() => cargar())
    );

    return () => {
      activo = false;
      bajas.forEach((baja) => baja && baja());
    };
  }, []);

  if (!datos) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-10 shadow-sm flex justify-center">
        <div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  const contadores = [
    { label: "Registrados", valor: datos.registrados, color: "text-slate-900" },
    { label: "Pendientes de comenzar", valor: datos.pendientesComenzar, color: "text-amber-600" },
    { label: "TAF finalizado", valor: datos.tafFinalizada, color: "text-blue-600" },
  ];
  const tafDatos = [
    { etiqueta: "Aprobados", valor: datos.aprobados, color: COLORES_TAF.aprobados },
    { etiqueta: "No aprobados", valor: datos.noAprobados, color: COLORES_TAF.noAprobados },
  ];
  const fuerzaDatos = FUERZAS.map((f) => ({ etiqueta: f.clave, valor: datos.porFuerza[f.clave], color: f.color }));
  const modalidadDatos = MODALIDADES.map((m) => ({
    etiqueta: m.clave,
    valor: datos.porModalidad[m.clave],
    color: m.color,
  }));
  const saltoDatos = [
    { etiqueta: "En condiciones de salto", valor: datos.enCondiciones, color: COLORES_SALTO.enCondiciones },
    {
      etiqueta: "Aun no en condiciones",
      valor: Math.max(datos.registrados - datos.enCondiciones, 0),
      color: COLORES_SALTO.resto,
    },
  ];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Resumen en vivo</p>
            <h2 className="text-lg font-bold text-slate-900 mt-0.5">REINSTRUCCIÓN ANUAL PARACAIDISTA</h2>
          </div>
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 mt-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            En vivo
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-4">
          {contadores.map((c) => (
            <div key={c.label} className="bg-slate-50 rounded-xl px-2 py-3 text-center">
              <p className={`text-2xl font-extrabold tabular-nums ${c.color}`}>{c.valor}</p>
              <p className="text-[11px] text-slate-500 leading-tight mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>

      <GraficaCircular
        titulo="Resultado del TAF"
        subtitulo={`Sobre ${datos.tafFinalizada} con evaluacion finalizada`}
        centroValor={datos.tafFinalizada}
        centroLabel="TAF finalizado"
        datos={tafDatos}
      />

      <GraficaCircular
        titulo="En condiciones de salto"
        subtitulo={`Sobre ${datos.registrados} anotados en el formulario`}
        centroValor={datos.registrados}
        centroLabel="Anotados"
        datos={saltoDatos}
      />

      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h3 className="font-semibold text-slate-800">Participantes por estacion</h3>
        <p className="text-xs text-slate-500 mt-0.5 mb-3">Que ya pasaron por la reinstruccion</p>
        <div className="space-y-2">
          {ESTACIONES.map((est) => (
            <div key={est} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
              <span className="text-sm text-slate-700">{est}</span>
              <span className="text-sm font-bold text-slate-900 tabular-nums">{datos.porEstacion[est]}</span>
            </div>
          ))}
        </div>
      </div>

      <GraficaCircular
        titulo="Anotados por modalidad"
        subtitulo="Segun el tipo de reinstruccion a realizar"
        centroValor={datos.registrados}
        centroLabel="Anotados"
        datos={modalidadDatos}
      />

      <GraficaCircular
        titulo="Registrados por fuerza"
        subtitulo="Segun el formulario de inscripcion"
        centroValor={datos.registrados}
        centroLabel="Anotados"
        datos={fuerzaDatos}
      />

      {onCerrar && (
        <button onClick={onCerrar} className="w-full text-sm text-blue-600 font-medium py-3">
          Volver
        </button>
      )}
    </div>
  );
}
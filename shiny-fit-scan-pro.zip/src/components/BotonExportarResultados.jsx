import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { buildProgresoMap, buildEstacionesMap, formatDocumento, ESTACIONES, esVoluntarioForm } from "@/lib/postulantes-utils";
import { calcularTAF, formatTiempo } from "@/lib/taf-puntaje";
import { descargarExcel } from "@/lib/exportar-excel";

const MESES = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];

const soloDigitos = (d) => String(d ?? "").replace(/\D/g, "");

// Exporta a Excel la totalidad de postulantes con sus datos de ingreso,
// los resultados del TAF (puntaje, concepto y APROBADO/NO APROBADO) y las
// estaciones de reinstruccion tecnica que paso cada uno, y la condicion final.
const ESTILO_ESTADO = {
  "EN CONDICIONES DE SALTO": "verde",
  "PENDIENTE EVALUACIÓN": "naranja",
  "PENDIENTE REINSTRUCCIÓN": "naranja",
  "TAF REPROBADO": "bordo",
  "NO VOLUNTARIO A SALTAR": "gris",
};

const COLUMNAS = [
  {
    key: "nombre",
    label: "Nombre completo",
    width: 220,
    style: "text",
    cellStyle: (v, fila) => ESTILO_ESTADO[fila.estado_final] || "text",
  },
  { key: "documento", label: "Documento", width: 115, style: "center" },
  { key: "edad", label: "Edad", width: 60, style: "center" },
  { key: "registro", label: "Fecha de registro", width: 130, style: "center" },
  { key: "barras", label: "Barras / Flexiones (rep)", width: 100, style: "center" },
  { key: "ptsBarras", label: "Puntos Barras / Flexiones", width: 84, style: "score" },
  { key: "abd", label: "Abdominales (rep)", width: 100, style: "center" },
  { key: "ptsAbd", label: "Puntos Abdominales", width: 84, style: "score" },
  { key: "carrera", label: "Carrera (tiempo)", width: 100, style: "center" },
  { key: "distancia", label: "Distancia (m)", width: 100, style: "center" },
  { key: "ptsCarrera", label: "Puntos Carrera", width: 84, style: "score" },
  { key: "total", label: "Puntaje total TAF", width: 84, style: "score" },
  { key: "concepto", label: "Concepto", width: 110, style: "center" },
  { key: "situacion", label: "Resultado TAF", width: 110, style: "center" },
  ...ESTACIONES.map((est, i) => ({
    key: `estacion_${i}`,
    label: est,
    width: 100,
    style: "center",
    cellStyle: { SI: "si", NO: "no" },
  })),
  { key: "estado_final", label: "Situación", width: 210, style: "center", cellStyle: ESTILO_ESTADO },
];

// Trae todas las paginas de una entidad (filtros del servidor, sin cortar en 500).
async function listarTodo(entity) {
  const out = [];
  let cursor;
  let guard = 0;
  do {
    const page = await entity.filter({}, { sort: "-created_date", limit: 500, cursor });
    out.push(...(page.items || []));
    cursor = page.next_cursor;
    guard += 1;
  } while (cursor && guard < 40);
  return out;
}

export default function BotonExportarResultados() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const exportar = async () => {
    setLoading(true);
    setMsg("");
    try {
      const [postulantes, evaluaciones, asistencias, form] = await Promise.all([
        listarTodo(base44.entities.Postulante),
        listarTodo(base44.entities.Evaluacion),
        listarTodo(base44.entities.AsistenciaEstacion),
        base44.functions
          .invoke("listarPostulantesForm", {})
          .then((res) => res.data?.postulantes || [])
          .catch(() => []),
      ]);

      if (postulantes.length === 0) {
        setMsg("No hay postulantes registrados para exportar.");
        return;
      }

      // La voluntad de saltar se declara en el formulario de ingreso
      const docsVoluntarios = new Set(
        form.filter((f) => esVoluntarioForm(f.voluntario)).map((f) => soloDigitos(f.documento))
      );

      const progresoMap = buildProgresoMap(evaluaciones);
      const estacionesMap = buildEstacionesMap(asistencias);

      const filas = postulantes.map((p) => {
        const prog = progresoMap[p.ID_NFC] || { byDisciplina: {}, evals: [] };
        const taf = calcularTAF(prog.evals, p.Edad);
        const est = estacionesMap[p.ID_NFC] || { count: 0, byEstacion: {} };
        const evBarras = prog.byDisciplina?.Barras;
        const evAbd = prog.byDisciplina?.Abdominales;
        const evCarrera = prog.byDisciplina?.Carrera;

        // Situacion final: falta prueba del TAF, TAF reprobado, falta reinstruccion o al dia
        const tafCompleto = Boolean(evBarras && evAbd && evCarrera) && taf.total !== null;
        const estacionesOk = ESTACIONES.every((nombre) => est.byEstacion?.[nombre]);
        let estadoFinal;
        if (!tafCompleto) estadoFinal = "PENDIENTE EVALUACIÓN";
        else if (taf.situacion === "NO APROBADO") estadoFinal = "TAF REPROBADO";
        else if (!estacionesOk) estadoFinal = "PENDIENTE REINSTRUCCIÓN";
        else if (!docsVoluntarios.has(soloDigitos(p.Documento))) estadoFinal = "NO VOLUNTARIO A SALTAR";
        else estadoFinal = "EN CONDICIONES DE SALTO";

        const fila = {
          nombre: p.Nombre_Completo,
          documento: formatDocumento(p.Documento),
          edad: p.Edad ?? "",
          registro: p.created_date
            ? new Date(p.created_date).toLocaleString("es-UY", {
                day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit",
              })
            : "",
          barras: evBarras ? `${evBarras.Resultado}${evBarras.Ejercicio === "Flexiones" ? " (flexiones)" : ""}` : "",
          ptsBarras: taf.ptsBarras ?? "",
          abd: evAbd ? evAbd.Resultado : "",
          ptsAbd: taf.ptsAbd ?? "",
          carrera: evCarrera ? formatTiempo(evCarrera.Resultado) : "",
          distancia: evCarrera?.Distancia ?? "",
          ptsCarrera: taf.ptsCarrera ?? "",
          total: taf.total ?? "",
          concepto: taf.concepto || "",
          situacion: taf.situacion || "PENDIENTE",
          estado_final: estadoFinal,
        };

        ESTACIONES.forEach((nombre, i) => {
          fila[`estacion_${i}`] = est.byEstacion?.[nombre] ? "SI" : "NO";
        });

        return fila;
      });

      const ahora = new Date();
      const fecha = `${String(ahora.getDate()).padStart(2, "0")}${MESES[ahora.getMonth()]}.${String(
        ahora.getFullYear()
      ).slice(-2)}`;
      const hora = `${String(ahora.getHours()).padStart(2, "0")}${String(ahora.getMinutes()).padStart(2, "0")}`;

      const enCondiciones = filas.filter((f) => f.estado_final === "EN CONDICIONES DE SALTO");
      descargarExcel(
        [
          { nombre: "Resultados", columnas: COLUMNAS, filas },
          { nombre: "EXPORTAR PARA MANIFIESTOS", columnas: COLUMNAS, filas: enCondiciones },
        ],
        `Resultado-TAF-${fecha}-${hora}hs.xls`
      );
    } catch (e) {
      setMsg("No se pudo generar el archivo.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mb-4">
      <Button
        type="button"
        onClick={exportar}
        disabled={loading}
        variant="outline"
        className="w-full gap-2 border-emerald-600 text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
          <path d="M7 10l5 5 5-5M12 15V3" />
        </svg>
        {loading ? "Generando Excel…" : "Exportar resultados"}
      </Button>
      {msg && <p className="text-sm text-red-600 mt-2">{msg}</p>}
    </div>
  );
}
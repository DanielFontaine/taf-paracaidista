import React from "react";
import { ESTACIONES } from "@/lib/postulantes-utils";

// Iniciales de cada estacion para mostrar en el indicador compacto.
const INICIALES = ["T", "C", "A", "N", "E"];

// Muestra una fila de 5 puntos (uno por estacion): verde si completo, rojo si pendiente.
export default function EstacionesDots({ byEstacion }) {
  return (
    <div className="flex items-center gap-1.5">
      {ESTACIONES.map((est, i) => {
        const done = !!byEstacion?.[est];
        return (
          <span
            key={est}
            title={est}
            className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
              done ? "bg-emerald-500 text-white" : "bg-red-400 text-white"
            }`}
          >
            {INICIALES[i]}
          </span>
        );
      })}
    </div>
  );
}
import React from "react";
import { formatDocumento, estadoProgreso } from "@/lib/postulantes-utils";
import ProgressBadge from "@/components/ProgressBadge";

// Lista de postulantes con progreso precomputado (progresoMap).
export default function PostulanteList({ postulantes, progresoMap, emptyMessage, onSelect }) {
  if (!postulantes || postulantes.length === 0) {
    return (
      <div className="text-center py-12 text-slate-400">
        <svg className="mx-auto mb-3 opacity-50" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>
        <p className="text-sm">{emptyMessage || "Sin postulantes."}</p>
      </div>
    );
  }

  return (
    <ul className="space-y-2">
      {postulantes.map((p) => {
        const prog = progresoMap?.[p.ID_NFC] || { count: 0 };
        return (
          <li key={p.id}>
            <button
              onClick={() => onSelect && onSelect(p)}
              className="w-full text-left bg-white border border-slate-200 rounded-xl px-4 py-3 hover:border-slate-300 hover:shadow-sm transition flex items-center gap-3"
            >
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-800 truncate">{p.Nombre_Completo}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs text-slate-500">{formatDocumento(p.Documento)}</span>
                  <span className="text-[11px] text-slate-400">·</span>
                  <span className="text-xs font-mono text-slate-400 truncate">{p.ID_NFC}</span>
                </div>
              </div>
              <ProgressBadge count={prog.count} />
            </button>
          </li>
        );
      })}
    </ul>
  );
}
import React from "react";
import { cn } from "@/lib/utils";

export default function EstacionesBadge({ count, size = "md" }) {
  const c = Math.max(0, Math.min(5, count));
  const done = c >= 5;
  const partial = c > 0 && c < 5;
  const sizes = {
    sm: "text-[11px] px-2 py-0.5",
    md: "text-xs px-2.5 py-1",
    lg: "text-sm px-3 py-1.5",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full font-semibold border",
        done
          ? "bg-emerald-100 text-emerald-700 border-emerald-200"
          : partial
          ? "bg-amber-100 text-amber-700 border-amber-200"
          : "bg-slate-100 text-slate-500 border-slate-200",
        sizes[size]
      )}
    >
      {done && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>}
      {c}/5
    </span>
  );
}
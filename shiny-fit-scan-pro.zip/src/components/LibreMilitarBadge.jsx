import React from "react";
import { cn } from "@/lib/utils";

// Indicador unico de la reinstruccion de caida libre militar (verde si ya paso, rojo si no)
export default function LibreMilitarBadge({ ok }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-full",
        ok ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
      )}
    >
      <svg
        width="12"
        height="12"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {ok ? <path d="M20 6L9 17l-5-5" /> : <path d="M18 6L6 18M6 6l12 12" />}
      </svg>
      Reinstruccion Caida Libre Militar
    </span>
  );
}
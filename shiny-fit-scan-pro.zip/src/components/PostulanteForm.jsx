import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { sanitizeDocumento, formatDocumento } from "@/lib/postulantes-utils";
import QrScanner from "@/components/QrScanner";

// Formulario para registrar/editar un postulante.
export default function PostulanteForm({ onSubmit, initial, submitting }) {
  const [idNfc, setIdNfc] = useState(initial?.ID_NFC || "");
  const [nombre, setNombre] = useState(initial?.Nombre_Completo || "");
  const [documento, setDocumento] = useState(initial?.Documento || "");
  const [edad, setEdad] = useState(initial?.Edad || "");
  const [err, setErr] = useState("");

  const handleDoc = (e) => setDocumento(sanitizeDocumento(e.target.value));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!idNfc.trim()) return setErr("Ingrese o escanee el codigo QR.");
    if (!nombre.trim()) return setErr("Ingrese el nombre completo.");
    const docDigits = sanitizeDocumento(documento);
    if (docDigits.length < 6) return setErr("El documento debe tener al menos 6 digitos.");
    const edadNum = parseInt(edad, 10);
    if (!edad || isNaN(edadNum) || edadNum < 18 || edadNum > 80) return setErr("Ingrese una edad válida (18-80).");
    setErr("");
    onSubmit({ ID_NFC: idNfc.trim().toUpperCase(), Nombre_Completo: nombre.trim(), Documento: docDigits, Edad: edadNum });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Codigo QR</label>
        <Input value={idNfc} readOnly placeholder="Se completa al escanear…" className="bg-slate-50 uppercase font-mono" />
        <QrScanner onScan={(id) => setIdNfc(id)} label="Escanear codigo QR" />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Nombre Completo</label>
        <Input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Apellido, Nombre" />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Edad</label>
        <Input
          value={edad}
          onChange={(e) => setEdad(e.target.value)}
          inputMode="numeric"
          type="number"
          min="18"
          max="80"
          placeholder="Ej: 25"
        />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Documento</label>
        <Input
          value={documento}
          onChange={handleDoc}
          inputMode="numeric"
          placeholder="Solo numeros"
        />
        {documento && (
          <p className="text-xs text-slate-500">
            Formato: <span className="font-semibold text-slate-700">{formatDocumento(documento)}</span>
          </p>
        )}
      </div>

      {err && <p className="text-sm text-red-600">{err}</p>}

      <Button type="submit" disabled={submitting} className="w-full">
        {submitting ? "Guardando…" : "Guardar postulante"}
      </Button>
    </form>
  );
}
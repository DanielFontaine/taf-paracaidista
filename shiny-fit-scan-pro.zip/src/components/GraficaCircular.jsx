import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

// Grafica circular (dona) con el total al centro y leyenda de valores y porcentajes.
export default function GraficaCircular({ titulo, subtitulo, datos, centroValor, centroLabel }) {
  const filas = datos.map((d) => ({ ...d, name: d.etiqueta, value: d.valor || 0 }));
  const total = filas.reduce((s, d) => s + d.value, 0);
  const pct = (n) => total > 0 ? Math.round(n / total * 100) : 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <h3 className="font-semibold text-slate-800">{titulo}</h3>
      {subtitulo && <p className="text-xs text-slate-500 mt-0.5 hidden">{subtitulo}</p>}

      {total === 0 ?
      <p className="text-sm text-slate-400 text-center py-8">Sin datos para graficar.</p> :

      <>
          <div className="relative h-52 mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                data={filas}
                dataKey="value"
                nameKey="name"
                innerRadius="60%"
                outerRadius="88%"
                paddingAngle={2}
                stroke="none"
                isAnimationActive={false}>
                
                  {filas.map((d) =>
                <Cell key={d.name} fill={d.color} />
                )}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">
                {centroValor ?? total}
              </span>
              {centroLabel &&
            <span className="text-[11px] uppercase tracking-wider text-slate-400 mt-0.5">{centroLabel}</span>
            }
            </div>
          </div>

          <ul className="mt-4 space-y-2">
            {filas.map((d) =>
          <li key={d.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: d.color }} />
                <span className="text-sm text-slate-700 flex-1 truncate">{d.name}</span>
                <span className="text-sm font-bold text-slate-900 tabular-nums">{d.value}</span>
                <span className="text-xs text-slate-500 tabular-nums w-9 text-right">{pct(d.value)}%</span>
              </li>
          )}
          </ul>
        </>
      }
    </div>);

}
import React, { useState, useRef, useCallback, useEffect } from "react";
import jsQR from "jsqr";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Escaner de codigo QR via camara + jsQR (funciona en iOS y Android).
// Abre la camara trasera, detecta un QR con el ID (ej: "QR-001") y llama onScan(id).
// Incluye respaldo de ingreso manual con prefijo "QR-" automatico.
export default function QrScanner({ onScan, label = "Escanear codigo QR" }) {
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState(null);
  const [manual, setManual] = useState("");
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(null);
  const onScanRef = useRef(onScan);

  useEffect(() => { onScanRef.current = onScan; }, [onScan]);

  const stopScan = useCallback(() => {
    setScanning(false);
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  useEffect(() => () => stopScan(), [stopScan]);

  const startScan = async () => {
    setError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("La camara no esta disponible en este dispositivo. Ingrese el ID manualmente.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      setScanning(true);
      requestAnimationFrame(async () => {
        if (!videoRef.current) return;
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
        const tick = () => {
          if (!videoRef.current || videoRef.current.readyState !== 4) {
            rafRef.current = requestAnimationFrame(tick);
            return;
          }
          const video = videoRef.current;
          const canvas = canvasRef.current;
          if (canvas) {
            const w = video.videoWidth || 480;
            const h = video.videoHeight || 480;
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext("2d", { willReadFrequently: true });
            ctx.drawImage(video, 0, 0, w, h);
            const imageData = ctx.getImageData(0, 0, w, h);
            const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: "dontInvert" });
            if (code && code.data) {
              const text = code.data.trim().toUpperCase();
              if (text) {
                stopScan();
                onScanRef.current(text);
                return;
              }
            }
          }
          rafRef.current = requestAnimationFrame(tick);
        };
        rafRef.current = requestAnimationFrame(tick);
      });
    } catch (e) {
      setError("No se pudo acceder a la camara: " + (e?.message || "error"));
      setScanning(false);
    }
  };

  const submitManual = (e) => {
    e.preventDefault();
    const digits = manual.replace(/\D/g, "").slice(0, 3);
    if (digits) onScan("QR-" + digits);
  };

  return (
    <div className="space-y-3">
      <Button
        type="button"
        onClick={scanning ? stopScan : startScan}
        variant={scanning ? "destructive" : "default"}
        className="w-full gap-2"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" />
          <path d="M14 14h3v3M21 14v7M14 21h3" />
        </svg>
        {scanning ? "Detener camara…" : label}
      </Button>

      <div className={scanning ? "relative rounded-2xl overflow-hidden border border-slate-200 bg-black aspect-square" : "hidden"}>
        <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-2/3 h-2/3 border-4 border-white/80 rounded-2xl shadow-[0_0_0_2000px_rgba(0,0,0,0.35)]"></div>
        </div>
        <p className="absolute bottom-3 left-0 right-0 text-center text-xs text-white/90 font-medium">
          Apunte la camara al codigo QR del postulante
        </p>
      </div>

      <canvas ref={canvasRef} className="hidden" />

      {error && <p className="text-xs text-red-600">{error}</p>}

      <form onSubmit={submitManual} className="flex gap-2">
        <div className="relative flex-1">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm pointer-events-none">QR-</span>
          <Input
            value={manual}
            onChange={(e) => setManual(e.target.value.replace(/\D/g, "").slice(0, 3))}
            placeholder="001"
            inputMode="numeric"
            maxLength={3}
            className="pl-12 font-mono"
          />
        </div>
        <Button type="submit" variant="secondary">Ingresar ID</Button>
      </form>
    </div>
  );
}
import React from "react";
import { cn } from "@/lib/utils";

export default function AppShell({ title, subtitle, onBack, children, accent = "slate" }) {
  const accentMap = {
    slate: "from-slate-700 to-slate-900",
    blue: "from-blue-600 to-blue-800",
    amber: "from-amber-500 to-amber-700",
    emerald: "from-emerald-600 to-emerald-800"
  };
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className={cn("shadow-lg text-[#000000] bg-[#5dab21]", accentMap[accent])}>
        <div className="max-w-3xl mx-auto px-5 py-5 flex items-center gap-3">
          {onBack &&
          <button
            onClick={onBack}
            className="rounded-full bg-white/15 hover:bg-white/25 transition p-2 -ml-1"
            aria-label="Volver">
            
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
          }
          <div className="flex-1">
            <h1 className="text-xl font-bold tracking-tight text-[hsl(var(--foreground))]">{title}</h1>
            {subtitle && <p className="text-sm text-white/80">{subtitle}</p>}
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-3xl w-full mx-auto px-5 py-6">{children}</main>
    </div>);

}
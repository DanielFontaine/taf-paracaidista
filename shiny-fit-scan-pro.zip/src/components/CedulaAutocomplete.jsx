import React, { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { formatDocumento, sanitizeDocumento } from "@/lib/postulantes-utils";

// Campo de busqueda por cedula con sugerencias: mientras se escribe muestra
// las cedulas que coinciden y permite seleccionar una con un toque.
export default function CedulaAutocomplete({
  value,
  onChange,
  onSelect,
  postulantes,
  placeholder = "Cedula",
  autoFocus = false,
  className = "",
}) {
  const [abierto, setAbierto] = useState(false);

  const sugerencias = useMemo(() => {
    const digitos = sanitizeDocumento(value);
    if (!digitos) return [];
    const vistos = new Set();
    const out = [];
    for (const p of postulantes || []) {
      const doc = sanitizeDocumento(p.documento);
      if (!doc || vistos.has(doc) || !doc.includes(digitos)) continue;
      vistos.add(doc);
      out.push(p);
      if (out.length >= 6) break;
    }
    return out;
  }, [value, postulantes]);

  const elegir = (p) => {
    onChange(sanitizeDocumento(p.documento));
    setAbierto(false);
    if (onSelect) onSelect(p);
  };

  return (
    <div className="relative flex-1">
      <Input
        value={value}
        onChange={(e) => { onChange(e.target.value); setAbierto(true); }}
        onFocus={() => setAbierto(true)}
        onBlur={() => setTimeout(() => setAbierto(false), 150)}
        placeholder={placeholder}
        inputMode="numeric"
        autoComplete="off"
        autoFocus={autoFocus}
        className={className}
      />
      {abierto && sugerencias.length > 0 && (
        <ul className="absolute left-0 right-0 top-full mt-1 z-30 max-h-64 overflow-y-auto rounded-xl border border-slate-200 bg-white shadow-lg">
          {sugerencias.map((p) => (
            <li key={sanitizeDocumento(p.documento)}>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => elegir(p)}
                className="w-full text-left px-3.5 py-2.5 hover:bg-slate-50 transition flex items-center justify-between gap-3"
              >
                <span className="text-sm font-mono font-semibold text-slate-800">{formatDocumento(p.documento)}</span>
                <span className="text-xs text-slate-500 truncate">
                  {[p.grado, p.nombre, p.apellido].filter(Boolean).join(" ") || p.unidad || ""}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
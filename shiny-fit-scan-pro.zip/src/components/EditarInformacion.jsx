import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { formatDocumento } from "@/lib/postulantes-utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const SUBTABS = [
  { key: "apto", label: "Apto Medico" },
  { key: "taf", label: "Resultados TAF" },
  { key: "nfc", label: "Codigos QR" },
];

export default function EditarInformacion({ postulantes, evaluaciones, aptos, onReload }) {
  const [sub, setSub] = useState("apto");
  const [msg, setMsg] = useState("");

  const nombreByNfc = {};
  (postulantes || []).forEach((p) => { nombreByNfc[p.ID_NFC] = p.Nombre_Completo; });
  const docByNfc = {};
  (postulantes || []).forEach((p) => { docByNfc[p.ID_NFC] = p.Documento; });

  return (
    <div>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 mb-4">
        {SUBTABS.map((s) => {
          const active = sub === s.key;
          return (
            <button
              key={s.key}
              onClick={() => { setSub(s.key); setMsg(""); }}
              className={`flex-shrink-0 rounded-full px-4 py-2 text-sm font-medium transition whitespace-nowrap ${
                active ? "bg-emerald-600 text-white shadow" : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300"
              }`}
            >
              {s.label}
            </button>
          );
        })}
      </div>

      {msg && (
        <p className="text-sm text-emerald-700 mb-3 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">{msg}</p>
      )}

      {sub === "apto" && <EditarApto aptos={aptos} postulantes={postulantes} onReload={onReload} setMsg={setMsg} />}
      {sub === "taf" && <EditarTaf evaluaciones={evaluaciones} nombreByNfc={nombreByNfc} onReload={onReload} setMsg={setMsg} />}
      {sub === "nfc" && <EditarNfc postulantes={postulantes} onReload={onReload} setMsg={setMsg} />}
    </div>
  );
}

function EditarApto({ aptos, postulantes, onReload, setMsg }) {
  const [busy, setBusy] = useState("");
  const nombreByDoc = {};
  (postulantes || []).forEach((p) => {
    const d = String(p.Documento || "").replace(/\D/g, "");
    if (d) nombreByDoc[d] = p.Nombre_Completo;
  });

  const eliminar = async (id, doc) => {
    if (!window.confirm("Eliminar la validacion de apto medico?")) return;
    setBusy(id);
    try {
      await base44.entities.AptoMedico.delete(id);
      setMsg("Apto medico eliminado.");
      await onReload();
    } catch (e) {
      setMsg("No se pudo eliminar.");
    } finally {
      setBusy("");
    }
  };

  if (!aptos || aptos.length === 0) {
    return <Empty text="No hay validaciones de apto medico registradas." />;
  }
  return (
    <ul className="space-y-2">
      {aptos.map((a) => {
        const doc = String(a.Documento || "").replace(/\D/g, "");
        return (
          <li key={a.id} className="bg-white border border-slate-200 rounded-xl px-4 py-3 shadow-sm flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="font-semibold text-slate-800 truncate">{nombreByDoc[doc] || "Postulante"}</p>
              <div className="flex flex-wrap items-center gap-2 mt-0.5">
                <span className="text-xs text-slate-500">{formatDocumento(a.Documento)}</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${a.Estado === "VALIDADO" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                  {a.Estado === "VALIDADO" ? "Validado" : "No validado"}
                </span>
                {a.Observacion && <span className="text-xs text-slate-500 truncate">· {a.Observacion}</span>}
              </div>
            </div>
            <Button variant="destructive" size="sm" disabled={busy === a.id} onClick={() => eliminar(a.id, doc)}>
              {busy === a.id ? "…" : "Eliminar"}
            </Button>
          </li>
        );
      })}
    </ul>
  );
}

function EditarTaf({ evaluaciones, nombreByNfc, onReload, setMsg }) {
  const [busy, setBusy] = useState("");
  const [openNfc, setOpenNfc] = useState(null);
  const [valores, setValores] = useState({});

  // Agrupar evaluaciones por ID_NFC (persona)
  const byNfc = {};
  (evaluaciones || []).forEach((ev) => {
    if (!byNfc[ev.ID_NFC]) byNfc[ev.ID_NFC] = [];
    byNfc[ev.ID_NFC].push(ev);
  });
  const nfcs = Object.keys(byNfc);

  const startEdit = (nfc) => {
    setOpenNfc(nfc);
    const init = {};
    byNfc[nfc].forEach((ev) => { init[ev.id] = String(ev.Resultado); });
    setValores(init);
  };

  const guardar = async (nfc) => {
    setBusy(nfc);
    try {
      await Promise.all(
        byNfc[nfc].map((ev) =>
          base44.entities.Evaluacion.update(ev.id, { Resultado: Number(valores[ev.id]) })
        )
      );
      setOpenNfc(null);
      setMsg("Resultados actualizados.");
      await onReload();
    } catch (e) {
      setMsg("No se pudo actualizar.");
    } finally {
      setBusy("");
    }
  };

  const eliminar = async (ev) => {
    if (!window.confirm("Eliminar este resultado?")) return;
    setBusy(ev.id);
    try {
      await base44.entities.Evaluacion.delete(ev.id);
      setMsg("Resultado eliminado.");
      await onReload();
    } catch (e) {
      setMsg("No se pudo eliminar.");
    } finally {
      setBusy("");
    }
  };

  if (!evaluaciones || evaluaciones.length === 0) {
    return <Empty text="No hay resultados TAF registrados." />;
  }
  return (
    <ul className="space-y-2">
      {nfcs.map((nfc) => {
        const evs = byNfc[nfc];
        const open = openNfc === nfc;
        return (
          <li key={nfc} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <button
              onClick={() => (open ? setOpenNfc(null) : startEdit(nfc))}
              className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left hover:bg-slate-50 transition"
            >
              <div className="min-w-0">
                <p className="font-semibold text-slate-800 truncate">{nombreByNfc[nfc] || nfc}</p>
                <p className="text-xs text-slate-500 mt-0.5">{evs.length} disciplina(s) evaluada(s)</p>
              </div>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`text-slate-400 transition ${open ? "rotate-180" : ""}`}><path d="M6 9l6 6 6-6"/></svg>
            </button>
            {open && (
              <div className="border-t border-slate-100 px-4 py-3 space-y-3">
                {evs.map((ev) => (
                  <div key={ev.id} className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-700">
                        {ev.Disciplina}{ev.Distancia ? ` (${ev.Distancia}m)` : ""}{ev.Ejercicio ? ` · ${ev.Ejercicio}` : ""}
                      </p>
                    </div>
                    <Input
                      type="number"
                      value={valores[ev.id] ?? ""}
                      onChange={(e) => setValores((v) => ({ ...v, [ev.id]: e.target.value }))}
                      className="w-24"
                    />
                    <Button size="sm" variant="destructive" disabled={busy === ev.id} onClick={() => eliminar(ev)}>
                      {busy === ev.id ? "…" : "Eliminar"}
                    </Button>
                  </div>
                ))}
                <div className="flex gap-2 pt-1">
                  <Button size="sm" disabled={busy === nfc} onClick={() => guardar(nfc)} className="flex-1">
                    {busy === nfc ? "Guardando…" : "Guardar resultados"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setOpenNfc(null)}>Cancelar</Button>
                </div>
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function EditarNfc({ postulantes, onReload, setMsg }) {
  const [busy, setBusy] = useState("");
  const [editId, setEditId] = useState(null);
  const [valor, setValor] = useState("");

  const guardar = async (p) => {
    const idUpper = valor.trim().toUpperCase();
    if (!idUpper) { setMsg("Ingrese un codigo QR."); return; }
    setBusy(p.id);
    try {
      // verificar que el nuevo ID no este asignado a otro
      const colision = await base44.entities.Postulante.filter({ ID_NFC: idUpper });
      if (colision && colision.some((c) => c.id !== p.id)) {
        setMsg("Ese codigo QR ya esta asignado a otro postulante.");
        setBusy("");
        return;
      }
      await base44.entities.Postulante.update(p.id, { ID_NFC: idUpper });
      setEditId(null);
      setMsg("Codigo QR actualizado.");
      await onReload();
    } catch (e) {
      setMsg("No se pudo actualizar.");
    } finally {
      setBusy("");
    }
  };

  const eliminar = async (p) => {
    if (!window.confirm("Eliminar la asignacion de codigo QR de este postulante?")) return;
    setBusy(p.id);
    try {
      await base44.entities.Postulante.delete(p.id);
      setMsg("Postulante eliminado.");
      await onReload();
    } catch (e) {
      setMsg("No se pudo eliminar.");
    } finally {
      setBusy("");
    }
  };

  if (!postulantes || postulantes.length === 0) {
    return <Empty text="No hay codigos QR asignados." />;
  }
  return (
    <ul className="space-y-2">
      {postulantes.map((p) => (
        <li key={p.id} className="bg-white border border-slate-200 rounded-xl px-4 py-3 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="font-semibold text-slate-800 truncate">{p.Nombre_Completo}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs text-slate-500">{formatDocumento(p.Documento)}</span>
                <span className="text-[11px] text-slate-400">·</span>
                <span className="text-xs font-mono text-slate-700">{p.ID_NFC}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {editId === p.id ? (
                <>
                  <Input
                    value={valor}
                    onChange={(e) => setValor(e.target.value)}
                    placeholder="QR-001"
                    className="w-28 font-mono"
                    autoFocus
                  />
                  <Button size="sm" disabled={busy === p.id} onClick={() => guardar(p)}>
                    {busy === p.id ? "…" : "OK"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setEditId(null)}>X</Button>
                </>
              ) : (
                <>
                  <Button size="sm" variant="outline" onClick={() => { setEditId(p.id); setValor(p.ID_NFC); }}>
                    Editar
                  </Button>
                  <Button size="sm" variant="destructive" disabled={busy === p.id} onClick={() => eliminar(p)}>
                    {busy === p.id ? "…" : "Eliminar"}
                  </Button>
                </>
              )}
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function Empty({ text }) {
  return (
    <div className="text-center py-12 text-slate-400">
      <p className="text-sm">{text}</p>
    </div>
  );
}
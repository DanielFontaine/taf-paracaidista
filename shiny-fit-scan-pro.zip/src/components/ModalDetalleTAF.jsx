import React from "react";
import { formatDocumento } from "@/lib/postulantes-utils";
import { calcularTAF, formatTiempo } from "@/lib/taf-puntaje";

const CONCEPTO_COLOR = {
  INSUFICIENTE: "bg-red-100 text-red-700 border-red-200",
  REGULAR: "bg-orange-100 text-orange-700 border-orange-200",
  BUENO: "bg-blue-100 text-blue-700 border-blue-200",
  "MUY BUENO": "bg-emerald-100 text-emerald-700 border-emerald-200",
  EXCELENTE: "bg-yellow-100 text-yellow-800 border-yellow-200",
};

export default function ModalDetalleTAF({ postulante, evaluaciones, onClose }) {
  if (!postulante) return null;

  const edad = postulante.Edad ?? null;
  const taf = edad !== null ? calcularTAF(evaluaciones, edad) : null;

  const barrasEv = evaluaciones.find((e) => e.Disciplina === "Barras");
  const abdEv = evaluaciones.find((e) => e.Disciplina === "Abdominales");
  const carreraEv = evaluaciones.find((e) => e.Disciplina === "Carrera");

  const disciplinas = [
    {
      label: barrasEv?.Ejercicio === "Flexiones" ? "Flexiones de brazo" : "Barras (barra fija)",
      resultado: barrasEv ? `${barrasEv.Resultado} rep` : "—",
      puntos: taf?.ptsBarras,
    },
    {
      label: "Abdominales",
      resultado: abdEv ? `${abdEv.Resultado} rep` : "—",
      puntos: taf?.ptsAbd,
    },
    {
      label: `Carrera ${carreraEv?.Distancia ? carreraEv.Distancia + "m" : ""}`,
      resultado: carreraEv ? formatTiempo(carreraEv.Resultado) : "—",
      puntos: taf?.ptsCarrera,
    },
  ];

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-emerald-700 text-white px-5 py-4">
          <h2 className="font-bold text-lg leading-tight">{postulante.Nombre_Completo}</h2>
          <p className="text-emerald-200 text-xs mt-0.5">
            Doc: {formatDocumento(postulante.Documento)}
            {edad !== null && ` · ${edad} años`}
          </p>
        </div>

        <div className="p-5 space-y-4">
          {/* Disciplinas */}
          <div className="space-y-2">
            {disciplinas.map((d) => (
              <div key={d.label} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                <div>
                  <p className="text-sm font-medium text-slate-800">{d.label}</p>
                  <p className="text-xs text-slate-500">{d.resultado}</p>
                </div>
                <div className="text-right">
                  {d.puntos !== null && d.puntos !== undefined ? (
                    <>
                      <p className="text-xl font-bold text-emerald-700">{d.puntos}</p>
                      <p className="text-[10px] text-slate-400">puntos</p>
                    </>
                  ) : (
                    <p className="text-sm text-slate-400">—</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Sin edad */}
          {edad === null && (
            <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
              Registre la edad del postulante para calcular el puntaje TAF.
            </p>
          )}

          {/* Puntaje final */}
          {taf?.total !== null && taf?.total !== undefined && (
            <div className={`rounded-xl border px-4 py-3 flex items-center justify-between ${CONCEPTO_COLOR[taf.concepto] || "bg-slate-100 text-slate-700 border-slate-200"}`}>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider opacity-70">Puntaje Final</p>
                <p className="text-2xl font-extrabold">{taf.total} <span className="text-sm font-normal">/ 300</span></p>
                <p className="text-sm font-semibold mt-0.5">{taf.concepto}</p>
              </div>
              <div className={`text-right`}>
                <span className={`inline-block text-sm font-bold px-3 py-1 rounded-full ${taf.situacion === "APROBADO" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
                  {taf.situacion}
                </span>
              </div>
            </div>
          )}

          {/* Incompleto */}
          {taf !== null && taf.total === null && (
            <p className="text-xs text-slate-500 text-center">
              Faltan pruebas para calcular el puntaje final.
            </p>
          )}

          <button
            onClick={onClose}
            className="w-full mt-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}
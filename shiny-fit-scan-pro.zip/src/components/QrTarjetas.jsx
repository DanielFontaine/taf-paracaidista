import React, { useState, useEffect, useRef, useCallback } from "react";
import QRCode from "qrcode";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Generador de codigo QR a partir de los 3 digitos ingresados manualmente.
// El usuario escribe los 3 digitos, se genera el QR y puede imprimirlo o guardarlo.
export default function QrTarjetas({ postulantes }) {
  const [digitos, setDigitos] = useState("");
  const [qrUrl, setQrUrl] = useState(null);
  const [nombreAsignado, setNombreAsignado] = useState(null);
  const canvasRef = useRef(null);

  const idCompleto = digitos.length === 3 ? "QR-" + digitos : null;

  // Buscar si el codigo QR esta asignado a alguien
  useEffect(() => {
    if (!idCompleto) {
      setNombreAsignado(null);
      return;
    }
    const p = (postulantes || []).find((x) => x.ID_NFC === idCompleto);
    setNombreAsignado(p?.Nombre_Completo || null);
  }, [idCompleto, postulantes]);

  // Generar QR automaticamente cuando hay 3 digitos
  useEffect(() => {
    if (!idCompleto) {
      setQrUrl(null);
      return;
    }
    let cancelled = false;
    QRCode.toDataURL(idCompleto, {
      width: 512,
      margin: 2,
      color: { dark: "#000000", light: "#FFFFFF" },
      errorCorrectionLevel: "M",
    }).then((url) => {
      if (!cancelled) setQrUrl(url);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [idCompleto]);

  const imprimir = useCallback(() => {
    if (!qrUrl) return;
    const w = window.open("", "_blank", "width=600,height=600");
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>QR ${idCompleto}</title>
      <style>
        @page { margin: 10mm; }
        body { font-family: system-ui, sans-serif; text-align: center; }
        img { width: 300px; height: 300px; }
        .id { font-family: monospace; font-weight: bold; font-size: 22px; margin-top: 10px; }
        .nombre { font-size: 16px; color: #444; margin-top: 4px; }
      </style></head><body>
      <img src="${qrUrl}" alt="${idCompleto}" />
      <div class="id">${idCompleto}</div>
      ${nombreAsignado ? `<div class="nombre">${nombreAsignado}</div>` : ""}
      <script>window.onload=function(){window.print();}</script>
      </body></html>`);
    w.document.close();
  }, [qrUrl, idCompleto, nombreAsignado]);

  const guardar = useCallback(() => {
    if (!qrUrl) return;
    const a = document.createElement("a");
    a.href = qrUrl;
    a.download = `QR_${idCompleto}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }, [qrUrl, idCompleto]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h3 className="font-semibold text-slate-800 mb-1">Generar codigo QR</h3>
        <p className="text-sm text-slate-500 mb-4">Escriba el numero del codigo QR</p>
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-[200px]">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm pointer-events-none">QR-</span>
            <Input
              value={digitos}
              onChange={(e) => setDigitos(e.target.value.replace(/\D/g, "").slice(0, 3))}
              placeholder="001"
              inputMode="numeric"
              maxLength={3}
              autoFocus
              className="pl-12 font-mono text-lg"
            />
          </div>
          {digitos.length > 0 && digitos.length < 3 && (
            <span className="text-xs text-slate-400">Faltan {3 - digitos.length} digito(s)</span>
          )}
        </div>
      </div>

      {qrUrl && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center">
          <div className="inline-block bg-white p-3 rounded-xl border border-slate-100">
            <img src={qrUrl} alt={idCompleto} className="w-56 h-56" ref={canvasRef} />
          </div>
          <div className="mt-3 font-mono font-bold text-lg text-slate-800">{idCompleto}</div>
          {nombreAsignado ? (
            <div className="text-sm text-slate-500 mt-1">{nombreAsignado}</div>
          ) : (
            <div className="text-sm text-amber-600 mt-1">Codigo QR no asignado</div>
          )}
          <div className="flex gap-3 mt-5">
            <Button type="button" className="flex-1 gap-2" onClick={guardar}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />
              </svg>
              Guardar imagen
            </Button>
            <Button type="button" variant="secondary" className="flex-1 gap-2" onClick={imprimir}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z" />
              </svg>
              Imprimir
            </Button>
          </div>
          <p className="text-xs text-slate-400 mt-3">
            En iPhone, toque "Guardar imagen" y luego "Guardar en Fotos" en la vista previa.
          </p>
        </div>
      )}
    </div>
  );
}
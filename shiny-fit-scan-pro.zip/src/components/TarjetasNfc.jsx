import React, { useState } from "react";
import QrTarjetas from "@/components/QrTarjetas";

// Genera QR-001 .. QR-100
const TODAS_LAS_TARJETAS = Array.from({ length: 100 }, (_, i) => `QR-${String(i + 1).padStart(3, "0")}`);

export default function TarjetasNfc({ postulantes }) {
  const [vista, setVista] = useState("stock");
  const asignadas = new Set((postulantes || []).map((p) => p.ID_NFC).filter(Boolean));
  const noAsignadas = TODAS_LAS_TARJETAS.filter((t) => !asignadas.has(t));

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setVista("stock")}
          className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition ${vista === "stock" ? "bg-slate-800 text-white" : "bg-white border border-slate-200 text-slate-600"}`}
        >
          Stock disponible
        </button>
        <button
          onClick={() => setVista("qr")}
          className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition ${vista === "qr" ? "bg-slate-800 text-white" : "bg-white border border-slate-200 text-slate-600"}`}
        >
          Codigos QR
        </button>
      </div>

      {vista === "qr" ? (
        <QrTarjetas postulantes={postulantes} />
      ) : (
        <>
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm mb-4">
            <p className="text-sm text-slate-500">
              Tarjetas no asignadas: <span className="font-bold text-slate-800">{noAsignadas.length}</span>
              <span className="text-slate-400"> / 100</span>
            </p>
          </div>
          {noAsignadas.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm">Todas las tarjetas estan asignadas.</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {noAsignadas.map((t) => (
                <div key={t} className="bg-white border border-slate-200 rounded-lg px-2 py-2 text-center shadow-sm">
                  <span className="text-sm font-mono font-semibold text-slate-700">{t}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
import React from "react";
import { formatTiempo } from "@/lib/carrera-utils";

// Lista de participantes de la carrera. Si recibe onSelect, cada corredor
// pendiente es un boton para detener su tiempo.
export default function ListaCorredores({
  items,
  onSelect,
  puedeDetener = true,
  mostrarEvaluador = false,
  emptyMsg = "Aun no hay participantes ingresados.",
}) {
  if (!items || items.length === 0) {
    return <p className="text-sm text-slate-500 text-center py-6">{emptyMsg}</p>;
  }

  const ordenados = [...items].sort((a, b) => {
    const an = Number(a.Numero) || 99999;
    const bn = Number(b.Numero) || 99999;
    if (an !== bn) return an - bn;
    return (a.created_date || "").localeCompare(b.created_date || "");
  });

  return (
    <ul className="space-y-2">
      {ordenados.map((p) => {
        const finalizado = p.Estado === "finalizado";
        const clickable = !!onSelect && !finalizado && puedeDetener;
        const Tag = clickable ? "button" : "div";
        return (
          <li key={p.id}>
            <Tag
              onClick={clickable ? () => onSelect(p) : undefined}
              className={`w-full text-left flex items-center gap-3 rounded-xl border px-3 py-3 transition ${
                finalizado ? "border-emerald-200 bg-emerald-50" : "border-slate-200 bg-white"
              } ${clickable ? "hover:border-amber-400 hover:bg-amber-50 active:scale-[0.99]" : ""}`}
            >
              <span
                className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                  finalizado ? "bg-emerald-600 text-white" : "bg-slate-800 text-white"
                }`}
              >
                {p.Numero || "—"}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{p.Nombre}</p>
                <p className="text-xs text-slate-500 truncate">
                  {p.Distancia ? `${p.Distancia.toLocaleString("es-UY")} m` : "Sin distancia"}
                  {mostrarEvaluador && p.Evaluador ? ` · ${p.Evaluador}` : ""}
                </p>
              </div>
              <div className="text-right flex-shrink-0">
                {finalizado ? (
                  <p className="text-base font-bold text-emerald-700 tabular-nums">{formatTiempo(p.Tiempo)}</p>
                ) : (
                  <p className="text-xs font-semibold text-amber-600">En carrera</p>
                )}
              </div>
            </Tag>
          </li>
        );
      })}
    </ul>
  );
}
import React, { useState } from "react";
import QrScanner from "@/components/QrScanner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { distanciaPorEdad, textosDistancia } from "@/lib/carrera-utils";
import { formatDocumento } from "@/lib/postulantes-utils";

// Ingreso de un participante a la carrera: escaneo de QR, edad (define el punto
// de partida) y numero de corredor.
export default function FormParticipante({ carrera, evaluador, onAdded }) {
  const [postulante, setPostulante] = useState(null);
  const [edad, setEdad] = useState("");
  const [numero, setNumero] = useState("");
  const [msg, setMsg] = useState("");
  const [buscando, setBuscando] = useState(false);
  const [guardando, setGuardando] = useState(false);

  const distancia = distanciaPorEdad(edad);
  const info = textosDistancia(distancia);

  const handleScan = async (idNfc) => {
    setBuscando(true);
    setMsg("");
    try {
      const matches = await base44.entities.Postulante.filter({ ID_NFC: idNfc });
      if (!matches || matches.length === 0) {
        setMsg(`El codigo ${idNfc} no esta asignado a ningun postulante.`);
        return;
      }
      const p = matches[0];
      setPostulante(p);
      setEdad(p.Edad != null ? String(p.Edad) : "");
      // El numero de corredor lo asigna manualmente el evaluador auxiliar.
      setNumero("");
    } catch (e) {
      setMsg("Error al buscar el postulante.");
    } finally {
      setBuscando(false);
    }
  };

  const confirmar = async (e) => {
    e.preventDefault();
    const ed = Number(edad);
    const d = distanciaPorEdad(ed);
    if (!d) {
      setMsg("Ingrese una edad valida.");
      return;
    }
    if (!numero.trim()) {
      setMsg("Ingrese el numero de corredor.");
      return;
    }
    setGuardando(true);
    setMsg("");
    try {
      await base44.entities.CarreraParticipante.create({
        Carrera_Id: carrera.id,
        Carrera_Codigo: carrera.Codigo,
        ID_NFC: postulante.ID_NFC,
        Nombre: postulante.Nombre_Completo,
        Documento: postulante.Documento,
        Edad: ed,
        Distancia: d,
        Numero: numero.trim(),
        Evaluador: evaluador?.nombre || "",
        Evaluador_Id: evaluador?.id || "",
        Estado: "en_carrera",
        Registrado: new Date().toISOString(),
      });
      setPostulante(null);
      setEdad("");
      setNumero("");
      setMsg("");
      onAdded?.();
    } catch (err) {
      setMsg("No se pudo ingresar el participante.");
    } finally {
      setGuardando(false);
    }
  };

  if (!postulante) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h3 className="font-semibold text-slate-800 mb-1">Ingresar nuevo participante</h3>
        <p className="text-sm text-slate-500 mb-4">Escanee el codigo QR o ingrese el numero</p>
        <QrScanner onScan={handleScan} label="Escanear QR del participante" />
        {buscando && <p className="text-sm text-sky-600 mt-3 animate-pulse">Buscando…</p>}
        {msg && <p className="text-sm text-red-600 mt-3">{msg}</p>}
      </div>
    );
  }

  return (
    <form onSubmit={confirmar} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Participante</p>
          <h3 className="text-lg font-bold text-slate-900 truncate">{postulante.Nombre_Completo}</h3>
          <p className="text-sm text-slate-500">Doc: {formatDocumento(postulante.Documento)}</p>
          <p className="text-xs text-slate-400 font-mono mt-0.5">{postulante.ID_NFC}</p>
        </div>
        <button
          type="button"
          onClick={() => { setPostulante(null); setMsg(""); }}
          className="text-xs text-sky-600 font-medium flex-shrink-0"
        >
          Cambiar
        </button>
      </div>

      <div>
        <label className="text-sm font-medium text-slate-700">Edad</label>
        <p className="text-xs text-slate-500 mb-2">Ingrese la edad del participante</p>
        <Input
          type="number"
          min="1"
          max="99"
          inputMode="numeric"
          value={edad}
          onChange={(e) => setEdad(e.target.value.replace(/\D/g, "").slice(0, 2))}
          placeholder="00"
          className="text-2xl font-semibold text-center"
          autoFocus
        />
      </div>

      {info && (
        <div className="rounded-xl border-2 border-amber-400 bg-amber-50 px-4 py-3">
          <p className="text-xs font-bold uppercase tracking-wider text-amber-700">Punto de partida</p>
          <p className="text-lg font-extrabold text-amber-900 mt-0.5">Debe correr {info.metros}</p>
          <p className="text-xs text-amber-700 mt-0.5">Corresponde a {info.rango}</p>
        </div>
      )}

      <div>
        <label className="text-sm font-medium text-slate-700">Numero de corredor</label>
        <p className="text-xs text-slate-500 mb-2">Ingrese el numero asignado para esta carrera</p>
        <Input
          value={numero}
          onChange={(e) => setNumero(e.target.value.replace(/\D/g, "").slice(0, 4))}
          inputMode="numeric"
          placeholder="—"
          className="text-center font-semibold"
        />
      </div>

      {msg && <p className="text-sm text-red-600">{msg}</p>}

      <div className="flex gap-2">
        <Button
          type="button"
          variant="secondary"
          className="flex-1"
          onClick={() => { setPostulante(null); setMsg(""); }}
        >
          Cancelar
        </Button>
        <Button type="submit" disabled={guardando || !distancia} className="flex-1">
          {guardando ? "Guardando…" : "Ingresar a la carrera"}
        </Button>
      </div>
    </form>
  );
}
import React from "react";
import { formatCronometro } from "@/lib/carrera-utils";

const TAMANOS = {
  md: "text-4xl",
  lg: "text-6xl",
  xl: "text-7xl sm:text-8xl md:text-9xl",
};

export default function TimerDisplay({ segundos, size = "lg", className = "" }) {
  return (
    <p className={`font-mono font-extrabold tabular-nums tracking-tight ${TAMANOS[size] || TAMANOS.lg} ${className}`}>
      {formatCronometro(segundos)}
    </p>
  );
}
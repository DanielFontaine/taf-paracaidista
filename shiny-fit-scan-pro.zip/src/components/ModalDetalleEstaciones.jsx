import React from "react";
import { ESTACIONES, formatDocumento } from "@/lib/postulantes-utils";

export default function ModalDetalleEstaciones({ postulante, estacionesMap, onClose }) {
  if (!postulante) return null;
  const prog = estacionesMap?.[postulante.ID_NFC] || { byEstacion: {} };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-violet-700 text-white px-5 py-4">
          <h2 className="font-bold text-lg leading-tight">{postulante.Nombre_Completo}</h2>
          <p className="text-violet-200 text-xs mt-0.5">
            Doc: {formatDocumento(postulante.Documento)}
          </p>
        </div>

        <div className="p-5 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Estaciones de Reinstruccion</p>
          {ESTACIONES.map((est) => {
            const done = !!prog.byEstacion?.[est];
            return (
              <div
                key={est}
                className={`flex items-center gap-3 rounded-xl border px-4 py-3 ${
                  done ? "border-emerald-200 bg-emerald-50" : "border-slate-100 bg-slate-50"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    done ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-400"
                  }`}
                >
                  {done ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/></svg>
                  )}
                </div>
                <p className={`text-sm font-medium flex-1 ${done ? "text-slate-800" : "text-slate-500"}`}>{est}</p>
                <span className={`text-xs font-semibold ${done ? "text-emerald-700" : "text-slate-400"}`}>
                  {done ? "Completo" : "Pendiente"}
                </span>
              </div>
            );
          })}

          <div className="flex items-center justify-between rounded-xl bg-violet-50 border border-violet-200 px-4 py-3 mt-3">
            <p className="text-sm font-semibold text-violet-800">Progreso total</p>
            <span className="text-sm font-bold text-violet-700">{prog.count || 0}/5</span>
          </div>

          <button
            onClick={onClose}
            className="w-full mt-2 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}